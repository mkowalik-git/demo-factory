/**
 * Oracle Machine Learning (OML) Analytics API
 *
 * Uses Oracle DBMS_DATA_MINING - trained, persisted in-database ML models:
 *   DEMAND_SURGE_MODEL      - Random Forest Classification (product surge detection)
 *   CUSTOMER_SEGMENT_MODEL  - K-Means Clustering (RFM customer segmentation)
 *   REVENUE_PREDICT_MODEL   - GLM Regression (order revenue prediction)
 *   PRODUCT_CLUSTER_MODEL   - K-Means Clustering (product grouping by behavior)
 *
 * Scoring functions: PREDICTION(), PREDICTION_PROBABILITY(), CLUSTER_ID(), CLUSTER_PROBABILITY()
 * All computation runs inside Oracle AI Database 26ai - no external ML framework.
 */

const express = require('express');
const router = express.Router();
const db = require('../config/database');
const { requireGlobalAccess } = require('../lib/accessControl');
const {
  refreshPersistentMlData,
  getMlPersistenceStatus,
  getSledOmlModelLifecycle,
  getPersistedDemandForecast,
  getPersistedCustomerSegments,
  getPersistedCommitmentForecast,
  getPersistedProductClusters,
  getPersistedCapacityIntelligence,
} = require('../lib/mlPersistenceService');

const PUBLIC_ML_KEYS = {
  products: 'services',
  customers: 'residentProfiles',
  churnDistribution: 'slaRiskDistribution',
  products_with_surge: 'services_with_demand_surge',
  PRODUCTS_WITH_SURGE: 'SERVICES_WITH_DEMAND_SURGE',
  total_customers: 'total_resident_profiles',
  TOTAL_CUSTOMERS: 'TOTAL_RESIDENT_PROFILES',
  total_products: 'total_services',
  total_revenue: 'total_service_value',
  churn_high: 'sla_high',
  centroid_product: 'centroid_service',
  centroid_product_id: 'centroid_service_id',
  product_id: 'service_id',
  product_name: 'service_name',
  brand_name: 'agency_or_program',
  unit_price: 'estimated_service_value',
  products_stocked: 'services_supported',
  PRODUCT_ID: 'SERVICE_ID',
  PRODUCT_NAME: 'SERVICE_NAME',
  BRAND_NAME: 'AGENCY_OR_PROGRAM',
  SOCIAL_TIER: 'PUBLIC_PROGRAM_TIER',
  UNIT_PRICE: 'ESTIMATED_SERVICE_VALUE',
  RECENT_MENTIONS: 'RECENT_SIGNALS',
  TOTAL_LIKES: 'TOTAL_ACKNOWLEDGEMENTS',
  TOTAL_SHARES: 'TOTAL_HANDOFFS',
  TOTAL_VIEWS: 'TOTAL_REACH',
  AVG_VIRALITY: 'AVG_PRIORITY',
  VIRAL_POSTS: 'CRITICAL_SIGNALS',
  TOTAL_POSTS: 'TOTAL_SIGNALS',
  ORDERS_RECENT: 'RECENT_SERVICE_REQUESTS',
  PEAK_MOMENTUM: 'PEAK_PRIORITY',
  REVENUE_OPPORTUNITY: 'SERVICE_VALUE_OPPORTUNITY',
  CUSTOMER_ID: 'CONSTITUENT_ID',
  FULL_NAME: 'RESIDENT_NAME',
  ORDER_COUNT: 'SERVICE_REQUEST_COUNT',
  TOTAL_SPENT: 'SERVICE_VALUE_EXPOSURE',
  AVG_ORDER_VALUE: 'AVG_REQUEST_VALUE',
  DAYS_SINCE_LAST_ORDER: 'DAYS_SINCE_LAST_SERVICE',
  MONETARY_SCORE: 'SERVICE_VALUE_SCORE',
  CHURN_RISK: 'SLA_RISK',
  PREDICTED_LTV: 'PREDICTED_SERVICE_VALUE',
  ACTUAL_REVENUE: 'ACTUAL_SERVICE_VALUE',
  AVG_GLM_PREDICTED: 'AVG_GLM_SERVICE_VALUE',
  MEAN_REVENUE: 'MEAN_SERVICE_VALUE',
  STDDEV_REVENUE: 'STDDEV_SERVICE_VALUE',
  mean_daily_revenue: 'mean_daily_service_value',
  STOCK_STATUS: 'CAPACITY_STATUS',
  QUANTITY_ON_HAND: 'AVAILABLE_CAPACITY',
  REORDER_POINT: 'CAPACITY_THRESHOLD',
  QUANTITY_RESERVED: 'RESERVED_CAPACITY',
  DAYS_OF_SUPPLY: 'DAYS_OF_CAPACITY',
  REVENUE_AT_RISK: 'SERVICE_VALUE_AT_RISK',
  SOCIAL_FACTOR: 'RESIDENT_SIGNAL_FACTOR',
  surge_products: 'surge_services',
  total_revenue_at_risk: 'total_service_value_at_risk',
  oml_demand_scores: 'service_demand_scores',
  oml_customer_segments: 'resident_need_segments',
  oml_commitment_forecasts: 'service_value_forecasts',
  oml_product_clusters: 'service_signal_clusters',
  oml_capacity_alerts: 'service_capacity_alerts',
};

const PUBLIC_MODEL_NAMES = {
  SLED_SERVICE_DEMAND_MODEL: 'STATE_LOCAL_GOVERNMENT_SERVICE_DEMAND_MODEL',
  SLED_RESIDENT_NEED_SEGMENT_MODEL: 'STATE_LOCAL_GOVERNMENT_RESIDENT_NEED_SEGMENT_MODEL',
  SLED_SERVICE_VALUE_MODEL: 'STATE_LOCAL_GOVERNMENT_SERVICE_VALUE_MODEL',
  SLED_CASE_SIGNAL_CLUSTER_MODEL: 'STATE_LOCAL_GOVERNMENT_CASE_SIGNAL_CLUSTER_MODEL',
};

function sanitizeMlString(value) {
  let next = String(value);
  Object.entries(PUBLIC_MODEL_NAMES).forEach(([internalName, publicName]) => {
    next = next.replaceAll(internalName, publicName);
  });
  return next
    .replace(/\bSLED\b/g, 'State and Local Government')
    .replace(/SLED_/g, 'STATE_LOCAL_GOVERNMENT_')
    .replace(/sled_/g, 'state_local_government_')
    .replace(/product_name/gi, 'service_name')
    .replace(/product_id/gi, 'service_id')
    .replace(/brand_name/gi, 'agency_or_program')
    .replace(/unit_price/gi, 'estimated_service_value')
    .replace(/customer_id/gi, 'constituent_id')
    .replace(/order_count/gi, 'service_request_count')
    .replace(/avg_order_value/gi, 'avg_request_value')
    .replace(/stock_status/gi, 'capacity_status')
    .replace(/oml_demand_scores/gi, 'service_demand_scores')
    .replace(/oml_customer_segments/gi, 'resident_need_segments')
    .replace(/oml_commitment_forecasts/gi, 'service_value_forecasts')
    .replace(/oml_product_clusters/gi, 'service_signal_clusters')
    .replace(/oml_capacity_alerts/gi, 'service_capacity_alerts')
    .replace(/avg_virality/gi, 'avg_priority')
    .replace(/viral_posts/gi, 'critical_signals')
    .replace(/total_posts/gi, 'total_signals')
    .replace(/\bsled\b/g, 'state_local_government')
    .replace(/\bCustomer Commitment\b/g, 'Resident Need')
    .replace(/\bcustomer commitment\b/g, 'resident need')
    .replace(/\bCustomer\b/g, 'Resident')
    .replace(/\bcustomer\b/g, 'resident')
    .replace(/\bProduct Signal\b/g, 'Service Signal')
    .replace(/\bproduct signal\b/g, 'service signal')
    .replace(/\bProduct\b/g, 'Public Service')
    .replace(/\bproduct\b/g, 'public service')
    .replace(/\bOrders\b/g, 'Service Requests')
    .replace(/\borders\b/g, 'service requests')
    .replace(/\bOrder\b/g, 'Service Request')
    .replace(/\border\b/g, 'service request')
    .replace(/\bRevenue\b/g, 'Service Value')
    .replace(/\brevenue\b/g, 'service value')
    .replace(/\bInventory\b/g, 'Capacity')
    .replace(/\binventory\b/g, 'capacity')
    .replace(/\bFulfillment\b/g, 'Resolution')
    .replace(/\bfulfillment\b/g, 'resolution')
    .replace(/\bStock\b/g, 'Capacity')
    .replace(/\bstock\b/g, 'capacity')
    .replace(/\bChurn\b/g, 'SLA risk')
    .replace(/\bchurn\b/g, 'SLA risk')
    .replace(/\bLTV\b/g, 'service value')
    .replace(/\bSocial\b/g, 'Resident-signal')
    .replace(/\bsocial\b/g, 'resident-signal')
    .replace(/\bVirality\b/g, 'Priority')
    .replace(/\bvirality\b/g, 'priority')
    .replace(/\bViral\b/g, 'Priority')
    .replace(/\bviral\b/g, 'priority');
}

function publicPriorityValue(value) {
  if (typeof value !== 'string') return value;
  const normalized = value.toLowerCase();
  if (normalized === 'mega_viral') return 'critical';
  if (normalized === 'viral') return 'escalating';
  return sanitizeMlString(value);
}

function sanitizeMlPayload(value, mappedKey = '') {
  if (Array.isArray(value)) {
    return value.map((item) => sanitizeMlPayload(item, mappedKey));
  }
  if (value && typeof value === 'object') {
    return Object.fromEntries(Object.entries(value).map(([key, entryValue]) => {
      const nextKey = PUBLIC_ML_KEYS[key] || key;
      return [nextKey, sanitizeMlPayload(entryValue, nextKey)];
    }));
  }
  if (typeof value === 'string') {
    if (mappedKey === 'PEAK_PRIORITY' || mappedKey === 'predicted_surge' || mappedKey === 'PREDICTED_SURGE') {
      return publicPriorityValue(value);
    }
    return sanitizeMlString(value);
  }
  return value;
}

router.use((req, res, next) => {
  const originalJson = res.json.bind(res);
  res.json = (payload) => originalJson(sanitizeMlPayload(payload));
  next();
});

function isMissingMlAssetError(err) {
  const message = String(err?.message || '');
  return /ORA-40284|ORA-00942/i.test(message)
    && /(model does not exist|DEMAND_SURGE_MODEL|CUSTOMER_SEGMENT_MODEL|REVENUE_PREDICT_MODEL|PRODUCT_CLUSTER_MODEL|OML_REVENUE_TRAINING_V|OML_PRODUCT_CLUSTER_V)/i.test(message);
}

async function handleMlRouteError(res, label, err, fallbackFn) {
  if (isMissingMlAssetError(err)) {
    try {
      const payload = await fallbackFn();
      return res.json(payload);
    } catch (fallbackErr) {
      console.error(`${label} fallback error:`, fallbackErr);
      return res.status(500).json({ error: fallbackErr.message });
    }
  }

  console.error(`${label} error:`, err);
  return res.status(500).json({ error: err.message });
}

function buildDemandProductFeaturesCte(lookbackHoursExpr = null) {
  const socialWhere = lookbackHoursExpr
    ? `WHERE CAST(sp.POSTED_AT AS DATE) >= SYSDATE - ${lookbackHoursExpr} / 24`
    : '';
  const salesWhere = lookbackHoursExpr
    ? `WHERE CAST(o.CREATED_AT AS DATE) >= SYSDATE - ${lookbackHoursExpr} / 24`
    : '';

  return `
    WITH product_features AS (
      SELECT /*+ NO_PARALLEL */
             p.PRODUCT_ID,
             p.PRODUCT_NAME,
             p.CATEGORY,
             b.BRAND_NAME,
             b.SOCIAL_TIER,
             p.UNIT_PRICE,
             NVL(eng.TOTAL_POSTS, 0)      AS TOTAL_POSTS,
             NVL(eng.AVG_SENTIMENT, 0.5)  AS AVG_SENTIMENT,
             NVL(eng.TOTAL_LIKES, 0)      AS TOTAL_LIKES,
             NVL(eng.TOTAL_SHARES, 0)     AS TOTAL_SHARES,
             NVL(eng.TOTAL_VIEWS, 0)      AS TOTAL_VIEWS,
             NVL(eng.AVG_VIRALITY, 0)     AS AVG_VIRALITY,
             NVL(eng.VIRAL_POSTS, 0)      AS VIRAL_POSTS,
             NVL(eng.RISING_POSTS, 0)     AS RISING_POSTS,
             NVL(sales.UNITS_SOLD, 0)     AS UNITS_SOLD,
             NVL(sales.REVENUE, 0)        AS REVENUE,
             NVL(eng.PEAK_MOMENTUM, 'normal') AS PEAK_MOMENTUM
      FROM PRODUCTS p
      JOIN BRANDS b ON b.BRAND_ID = p.BRAND_ID
      LEFT JOIN (
        SELECT ppm.PRODUCT_ID,
               COUNT(*) AS TOTAL_POSTS,
               AVG(sp.SENTIMENT_SCORE) AS AVG_SENTIMENT,
               SUM(sp.LIKES_COUNT) AS TOTAL_LIKES,
               SUM(sp.SHARES_COUNT) AS TOTAL_SHARES,
               SUM(sp.VIEWS_COUNT) AS TOTAL_VIEWS,
               AVG(sp.VIRALITY_SCORE) AS AVG_VIRALITY,
               SUM(CASE WHEN sp.MOMENTUM_FLAG = 'viral' THEN 1 ELSE 0 END) AS VIRAL_POSTS,
               SUM(CASE WHEN sp.MOMENTUM_FLAG = 'rising' THEN 1 ELSE 0 END) AS RISING_POSTS,
               MAX(sp.MOMENTUM_FLAG) AS PEAK_MOMENTUM
        FROM POST_PRODUCT_MENTIONS ppm
        JOIN SOCIAL_POSTS sp ON ppm.POST_ID = sp.POST_ID
        ${socialWhere}
        GROUP BY ppm.PRODUCT_ID
      ) eng ON p.PRODUCT_ID = eng.PRODUCT_ID
      LEFT JOIN (
        SELECT oi.PRODUCT_ID,
               SUM(oi.QUANTITY) AS UNITS_SOLD,
               SUM(oi.LINE_TOTAL) AS REVENUE
        FROM ORDER_ITEMS oi
        JOIN ORDERS o ON o.ORDER_ID = oi.ORDER_ID
        ${salesWhere}
        GROUP BY oi.PRODUCT_ID
      ) sales ON p.PRODUCT_ID = sales.PRODUCT_ID
      WHERE p.IS_ACTIVE = 1
        AND (eng.PRODUCT_ID IS NOT NULL OR sales.PRODUCT_ID IS NOT NULL)
    )`;
}

router.get('/persistence/status', requireGlobalAccess, async (req, res) => {
  try {
    const status = await getMlPersistenceStatus();
    res.json({
      ...status,
      modelLifecycle: status.modelLifecycle,
    });
  } catch (err) {
    console.error('ML persistence status error:', err);
    res.status(500).json({ error: err.message });
  }
});

router.get('/models/status', requireGlobalAccess, async (req, res) => {
  try {
    res.json(await getSledOmlModelLifecycle());
  } catch (err) {
    console.error('ML model lifecycle status error:', err);
    res.status(500).json({ error: err.message });
  }
});

router.post('/persistence/refresh', requireGlobalAccess, async (req, res) => {
  try {
    const result = await refreshPersistentMlData({
      source: 'api-refresh',
      username: req.demoUser,
    });
    res.json({ ok: true, ...result });
  } catch (err) {
    console.error('ML persistence refresh error:', err);
    res.status(500).json({ error: err.message });
  }
});

function heuristicSurgeProbabilitySql(alias) {
  return `ROUND(LEAST(99,
    NVL(${alias}.AVG_VIRALITY, 0) * 0.45 +
    LEAST(NVL(${alias}.TOTAL_POSTS, 0), 40) * 0.9 +
    LEAST(NVL(${alias}.VIRAL_POSTS, 0), 10) * 6 +
    LEAST(NVL(${alias}.RISING_POSTS, 0), 15) * 2 +
    LEAST(NVL(${alias}.TOTAL_VIEWS, 0) / 2000, 25) +
    LEAST(NVL(${alias}.UNITS_SOLD, 0), 80) * 0.2
  ), 1)`;
}

async function fallbackDemandForecast({ limit, lookbackHours }) {
  const result = await db.execute(`
    ${buildDemandProductFeaturesCte(':lookback')}
    , scored_products AS (
      SELECT pf.*,
             ${heuristicSurgeProbabilitySql('pf')} AS SURGE_PROBABILITY
      FROM product_features pf
    )
    SELECT
      sp.PRODUCT_ID,
      sp.PRODUCT_NAME,
      sp.CATEGORY,
      sp.BRAND_NAME,
      sp.SOCIAL_TIER,
      sp.UNIT_PRICE,
      sp.TOTAL_POSTS AS RECENT_MENTIONS,
      ROUND(sp.AVG_VIRALITY, 1) AS AVG_VIRALITY,
      sp.TOTAL_LIKES,
      sp.TOTAL_SHARES,
      sp.TOTAL_VIEWS,
      sp.UNITS_SOLD AS ORDERS_RECENT,
      sp.PEAK_MOMENTUM,
      CASE
        WHEN sp.SURGE_PROBABILITY >= 65 THEN 'SURGE'
        WHEN sp.SURGE_PROBABILITY >= 45 THEN 'WATCH'
        ELSE 'STABLE'
      END AS PREDICTED_SURGE,
      sp.SURGE_PROBABILITY,
      GREATEST(0, ROUND(
        sp.UNITS_SOLD * (1 + sp.SURGE_PROBABILITY / 100 * 2) + sp.TOTAL_POSTS * 0.5,
      0)) AS PREDICTED_DEMAND,
      ROUND(sp.SURGE_PROBABILITY, 1) AS UPLIFT_PCT,
      ROUND(
        LEAST(99, sp.SURGE_PROBABILITY * 0.9 + CASE WHEN sp.TOTAL_POSTS > 0 THEN 10 ELSE 0 END),
      0) AS CONFIDENCE_PCT,
      GREATEST(0, ROUND(
        (sp.UNITS_SOLD * (1 + sp.SURGE_PROBABILITY / 100 * 2) + sp.TOTAL_POSTS * 0.5)
        * sp.UNIT_PRICE,
      2)) AS REVENUE_OPPORTUNITY
    FROM scored_products sp
    WHERE sp.TOTAL_POSTS > 0 OR sp.UNITS_SOLD > 0
    ORDER BY sp.SURGE_PROBABILITY DESC, sp.AVG_VIRALITY DESC
    FETCH FIRST :limit ROWS ONLY
  `, { lookback: lookbackHours, limit });

  return {
    products: result.rows,
    meta: {
      lookback_hours: lookbackHours,
      model: 'Demand signal heuristic (fallback)',
      algorithm: 'HEURISTIC_SCORE',
      scoring: 'Weighted social engagement + sales signal',
      features: ['category', 'unit_price', 'total_posts', 'avg_sentiment', 'total_likes',
                 'total_shares', 'total_views', 'avg_virality', 'viral_posts', 'rising_posts',
                 'units_sold', 'revenue'],
      engine: 'Oracle SQL fallback - persisted DBMS_DATA_MINING model not available',
      fallback: true,
    },
  };
}

async function fallbackCustomerSegments({ limit }) {
  const result = await db.execute(`
    WITH customer_metrics AS (
      SELECT /*+ NO_PARALLEL */
             c.CUSTOMER_ID,
             c.FIRST_NAME || ' ' || c.LAST_NAME AS FULL_NAME,
             c.CITY,
             c.STATE_PROVINCE AS STATE,
             c.SERVICE_REGION_CODE,
             c.LIFETIME_VALUE,
             NVL(rfm.RECENCY_DAYS, 999) AS RECENCY_DAYS,
             NVL(rfm.FREQUENCY, 0) AS FREQUENCY,
             NVL(rfm.MONETARY, 0) AS MONETARY,
             NVL(rfm.AVG_ORDER_VALUE, 0) AS AVG_ORDER_VALUE,
             NVL(rfm.TOTAL_ITEMS, 0) AS TOTAL_ITEMS,
             rfm.FREQUENCY AS ORDER_COUNT,
             rfm.MONETARY AS TOTAL_SPENT,
             rfm.RECENCY_DAYS AS DAYS_SINCE_LAST_ORDER
      FROM CUSTOMERS c
      LEFT JOIN (
        SELECT o.CUSTOMER_ID,
               ROUND(SYSDATE - CAST(MAX(o.CREATED_AT) AS DATE)) AS RECENCY_DAYS,
               COUNT(DISTINCT o.ORDER_ID) AS FREQUENCY,
               SUM(o.ORDER_TOTAL) AS MONETARY,
               AVG(o.ORDER_TOTAL) AS AVG_ORDER_VALUE,
               NVL(SUM(oi_cnt.ITEM_COUNT), 0) AS TOTAL_ITEMS
        FROM ORDERS o
        LEFT JOIN (
          SELECT ORDER_ID, SUM(QUANTITY) AS ITEM_COUNT
          FROM ORDER_ITEMS
          GROUP BY ORDER_ID
        ) oi_cnt ON o.ORDER_ID = oi_cnt.ORDER_ID
        GROUP BY o.CUSTOMER_ID
      ) rfm ON c.CUSTOMER_ID = rfm.CUSTOMER_ID
    ),
    scored AS (
      SELECT cm.*,
             NTILE(4) OVER (ORDER BY cm.RECENCY_DAYS ASC) AS RECENCY_SCORE,
             NTILE(4) OVER (ORDER BY cm.FREQUENCY DESC) AS FREQUENCY_SCORE,
             NTILE(4) OVER (ORDER BY cm.MONETARY DESC) AS MONETARY_SCORE
      FROM customer_metrics cm
      WHERE cm.FREQUENCY > 0
    ),
    segmented AS (
      SELECT s.*,
             MOD(s.RECENCY_SCORE + s.FREQUENCY_SCORE + s.MONETARY_SCORE - 1, 4) + 1 AS OML_CLUSTER_ID,
             ROUND((s.RECENCY_SCORE + s.FREQUENCY_SCORE + s.MONETARY_SCORE) / 12, 3) AS CLUSTER_PROBABILITY,
             CASE
               WHEN s.RECENCY_SCORE = 4 AND s.FREQUENCY_SCORE >= 3 AND s.MONETARY_SCORE >= 3 THEN 'Champion'
               WHEN s.RECENCY_SCORE >= 3 AND s.FREQUENCY_SCORE >= 3 THEN 'Loyal'
               WHEN s.RECENCY_SCORE = 4 AND s.FREQUENCY_SCORE <= 2 THEN 'New Customer'
               WHEN s.RECENCY_SCORE <= 2 AND s.MONETARY_SCORE = 4 THEN 'At Risk'
               WHEN s.RECENCY_SCORE = 1 AND s.FREQUENCY_SCORE <= 2 THEN 'Lost'
               WHEN s.MONETARY_SCORE = 4 AND s.RECENCY_SCORE >= 2 THEN 'Big Spender'
               WHEN s.RECENCY_SCORE >= 3 AND s.MONETARY_SCORE <= 2 THEN 'Promising'
               ELSE 'Potential'
             END AS SEGMENT,
             CASE
               WHEN NVL(s.DAYS_SINCE_LAST_ORDER, 999) > 60 THEN 'High'
               WHEN NVL(s.DAYS_SINCE_LAST_ORDER, 999) > 30 THEN 'Medium'
               ELSE 'Low'
             END AS CHURN_RISK,
             ROUND(
               s.AVG_ORDER_VALUE * GREATEST(1, NVL(s.FREQUENCY, 0) / NULLIF(s.RECENCY_DAYS, 0) * 365),
             2) AS PREDICTED_LTV
      FROM scored s
    )
    SELECT
      CUSTOMER_ID,
      FULL_NAME,
      CITY,
      STATE,
      SERVICE_REGION_CODE,
      NVL(ORDER_COUNT, 0) AS ORDER_COUNT,
      ROUND(NVL(TOTAL_SPENT, 0), 2) AS TOTAL_SPENT,
      ROUND(AVG_ORDER_VALUE, 2) AS AVG_ORDER_VALUE,
      NVL(DAYS_SINCE_LAST_ORDER, 999) AS DAYS_SINCE_LAST_ORDER,
      OML_CLUSTER_ID,
      CLUSTER_PROBABILITY,
      RECENCY_SCORE,
      FREQUENCY_SCORE,
      MONETARY_SCORE,
      SEGMENT,
      CHURN_RISK,
      PREDICTED_LTV
    FROM segmented
    ORDER BY TOTAL_SPENT DESC
    FETCH FIRST :limit ROWS ONLY
  `, { limit });

  const segMap = {};
  result.rows.forEach(r => {
    const seg = r.SEGMENT;
    if (!segMap[seg]) {
      segMap[seg] = { segment: seg, count: 0, total_revenue: 0, avg_rfm: 0, churn_high: 0 };
    }
    segMap[seg].count++;
    segMap[seg].total_revenue += Number(r.TOTAL_SPENT) || 0;
    segMap[seg].avg_rfm += (Number(r.RECENCY_SCORE) || 0) + (Number(r.FREQUENCY_SCORE) || 0) + (Number(r.MONETARY_SCORE) || 0);
    if (r.CHURN_RISK === 'High') segMap[seg].churn_high++;
  });

  const segmentSummary = Object.values(segMap).map(s => ({
    ...s,
    total_revenue: Math.round(s.total_revenue * 100) / 100,
    avg_rfm: Math.round((s.avg_rfm / s.count) * 10) / 10,
  })).sort((a, b) => b.count - a.count);

  const churnDist = { High: 0, Medium: 0, Low: 0 };
  result.rows.forEach(r => { churnDist[r.CHURN_RISK] = (churnDist[r.CHURN_RISK] || 0) + 1; });

  return {
    customers: result.rows,
    segmentSummary,
    churnDistribution: Object.entries(churnDist).map(([risk, count]) => ({ risk, count })),
    total: result.rows.length,
    meta: {
      model: 'RFM segmentation heuristic (fallback)',
      algorithm: 'QUARTILE_SEGMENTATION',
      scoring: 'NTILE quartiles + deterministic segment rules',
      dimensions: ['lifetime_value', 'recency_days', 'frequency', 'monetary', 'avg_order_value', 'total_items'],
      engine: 'Oracle SQL fallback - persisted DBMS_DATA_MINING model not available',
      clusters: segmentSummary.length,
      fallback: true,
    },
  };
}

async function fallbackRevenueForecast({ lookbackDays, forecastDays }) {
  const histResult = await db.execute(`
    WITH daily_rev AS (
      SELECT /*+ NO_PARALLEL */
             TRUNC(CAST(CREATED_AT AS DATE), 'DD') AS DAY_BUCKET,
             SUM(ORDER_TOTAL) AS REVENUE,
             COUNT(ORDER_ID) AS ORDER_COUNT,
             AVG(ORDER_TOTAL) AS AVG_ORDER_VALUE,
             ROW_NUMBER() OVER (ORDER BY TRUNC(CAST(CREATED_AT AS DATE), 'DD')) AS RN
      FROM ORDERS
      WHERE CAST(CREATED_AT AS DATE) >= SYSDATE - :lookback
      GROUP BY TRUNC(CAST(CREATED_AT AS DATE), 'DD')
    ),
    params AS (
      SELECT
        REGR_SLOPE(REVENUE, RN) AS SLOPE,
        REGR_INTERCEPT(REVENUE, RN) AS INTERCEPT,
        REGR_R2(REVENUE, RN) AS R2,
        AVG(REVENUE) AS MEAN_REVENUE,
        STDDEV(REVENUE) AS STDDEV_REVENUE,
        MAX(RN) AS MAX_RN,
        CORR(REVENUE, RN) AS CORRELATION
      FROM daily_rev
    )
    SELECT
      TO_CHAR(d.DAY_BUCKET, 'YYYY-MM-DD') AS DAY,
      ROUND(d.REVENUE, 2) AS ACTUAL_REVENUE,
      d.ORDER_COUNT,
      ROUND(d.AVG_ORDER_VALUE, 2) AS AVG_ORDER_VALUE,
      ROUND(p.SLOPE * d.RN + p.INTERCEPT, 2) AS TREND_LINE,
      ROUND(AVG(d.REVENUE) OVER (
        ORDER BY d.RN ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
      ), 2) AS MA_7D,
      ROUND(p.R2, 4) AS R_SQUARED,
      ROUND(p.SLOPE, 2) AS DAILY_SLOPE,
      ROUND(p.INTERCEPT, 2) AS INTERCEPT,
      ROUND(p.MEAN_REVENUE, 2) AS MEAN_REVENUE,
      ROUND(p.STDDEV_REVENUE, 2) AS STDDEV_REVENUE,
      ROUND(p.CORRELATION, 4) AS CORRELATION,
      p.MAX_RN AS MAX_RN,
      CAST(NULL AS NUMBER) AS AVG_GLM_PREDICTED,
      CAST(NULL AS NUMBER) AS GLM_CORRELATION,
      0 AS IS_FORECAST
    FROM daily_rev d
    CROSS JOIN params p
    ORDER BY d.DAY_BUCKET
  `, { lookback: lookbackDays });

  if (!histResult.rows.length) {
    return { historical: [], forecast: [], model: null };
  }

  const last = histResult.rows[histResult.rows.length - 1];
  const slope = Number(last.DAILY_SLOPE) || 0;
  const intercept = Number(last.INTERCEPT) || 0;
  const maxRn = Number(last.MAX_RN) || 0;
  const stddev = Number(last.STDDEV_REVENUE) || 0;

  const forecast = [];
  for (let i = 1; i <= forecastDays; i++) {
    const futureRn = maxRn + i;
    const predicted = Math.max(0, slope * futureRn + intercept);
    const ci = stddev * (1 + i * 0.07);
    const d = new Date();
    d.setDate(d.getDate() + i);

    forecast.push({
      DAY: d.toISOString().slice(0, 10),
      ACTUAL_REVENUE: null,
      ORDER_COUNT: null,
      AVG_ORDER_VALUE: null,
      TREND_LINE: Math.round(predicted * 100) / 100,
      MA_7D: null,
      CI_LOWER: Math.round(Math.max(0, predicted - ci) * 100) / 100,
      CI_UPPER: Math.round((predicted + ci) * 100) / 100,
      IS_FORECAST: 1,
    });
  }

  return {
    historical: histResult.rows,
    forecast,
    model: {
      type: 'OLS Trend (fallback)',
      algorithm: 'REGR_SLOPE / REGR_R2',
      engine: 'Oracle SQL fallback - persisted GLM model not available',
      r_squared: Number(last.R_SQUARED),
      correlation: Number(last.CORRELATION),
      glm_correlation: null,
      avg_glm_predicted: null,
      daily_slope: slope,
      intercept,
      mean_daily_revenue: Number(last.MEAN_REVENUE),
      stddev,
      observations: maxRn,
      lookback_days: lookbackDays,
      forecast_days: forecastDays,
      fallback: true,
    },
  };
}

async function fallbackSummary() {
  const [surgeCount, customers, segmentCount, modelCount, regr] = await Promise.all([
    db.execute(`
      ${buildDemandProductFeaturesCte('720')}
      , scored_products AS (
        SELECT pf.PRODUCT_ID,
               ${heuristicSurgeProbabilitySql('pf')} AS SURGE_PROBABILITY
        FROM product_features pf
      )
      SELECT COUNT(*) AS CNT
      FROM scored_products
      WHERE SURGE_PROBABILITY >= 65
    `),
    db.execute(`SELECT COUNT(*) AS CNT FROM CUSTOMERS`),
    db.execute(`
      WITH resident_metrics AS (
        SELECT c.customer_id,
               COUNT(o.order_id) AS request_count,
               NVL(SUM(o.order_total), 0) AS service_value
        FROM customers c
        LEFT JOIN orders o ON o.customer_id = c.customer_id
        GROUP BY c.customer_id
      )
      SELECT COUNT(DISTINCT CASE
               WHEN request_count >= 5 AND service_value >= 5000 THEN 'High Need / High Activity'
               WHEN request_count >= 5 THEN 'Frequent Service User'
               WHEN service_value >= 5000 THEN 'High Value Exposure'
               WHEN request_count > 0 THEN 'Standard Support'
             END) AS CNT
      FROM resident_metrics
      WHERE request_count > 0
    `),
    db.execute(`
      SELECT CASE
               WHEN SYS_CONTEXT('SLED_APP_CTX', 'AUTHENTICATED') = 'Y'
                AND SYS_CONTEXT('SLED_APP_CTX', 'ACCESS_SCOPE') = 'GLOBAL'
               THEN (SELECT COUNT(*) FROM USER_MINING_MODELS WHERE ALGORITHM != 'ONNX')
               ELSE 0
             END AS CNT
      FROM dual
    `),
    db.execute(`
      SELECT /*+ NO_PARALLEL */
        ROUND(REGR_SLOPE(DAY_REV, RN), 2) AS SLOPE,
        ROUND(REGR_R2(DAY_REV, RN), 4) AS R2
      FROM (
        SELECT SUM(ORDER_TOTAL) AS DAY_REV,
               ROW_NUMBER() OVER (ORDER BY TRUNC(CAST(CREATED_AT AS DATE))) AS RN
        FROM ORDERS
        WHERE CAST(CREATED_AT AS DATE) >= SYSDATE - 30
        GROUP BY TRUNC(CAST(CREATED_AT AS DATE))
      )
    `),
  ]);

  return {
    products_with_surge: surgeCount.rows[0]?.CNT || 0,
    total_customers: customers.rows[0]?.CNT || 0,
    rfm_segments: segmentCount.rows[0]?.CNT || 0,
    revenue_slope: regr.rows[0]?.SLOPE || 0,
    revenue_r2: regr.rows[0]?.R2 || 0,
    models_active: modelCount.rows[0]?.CNT || 0,
  };
}

function buildProductClusterFeaturesCte() {
  return `
    WITH product_cluster_features AS (
      SELECT
        p.PRODUCT_ID,
        p.PRODUCT_NAME,
        p.CATEGORY,
        p.UNIT_PRICE,
        b.BRAND_NAME,
        NVL(sales.UNITS_SOLD, 0) AS UNITS_SOLD,
        NVL(sales.REVENUE, 0) AS PRODUCT_REVENUE,
        NVL(eng.TOTAL_ENGAGEMENT, 0) AS TOTAL_ENGAGEMENT,
        NVL(eng.AVG_SENTIMENT, 0.5) AS AVG_SENTIMENT,
        NVL(eng.AVG_VIRALITY, 0) AS AVG_VIRALITY
      FROM PRODUCTS p
      JOIN BRANDS b ON p.BRAND_ID = b.BRAND_ID
      LEFT JOIN (
        SELECT PRODUCT_ID,
               SUM(QUANTITY) AS UNITS_SOLD,
               SUM(LINE_TOTAL) AS REVENUE
        FROM ORDER_ITEMS
        GROUP BY PRODUCT_ID
      ) sales ON p.PRODUCT_ID = sales.PRODUCT_ID
      LEFT JOIN (
        SELECT ppm.PRODUCT_ID,
               SUM(sp.LIKES_COUNT + sp.SHARES_COUNT + sp.VIEWS_COUNT) AS TOTAL_ENGAGEMENT,
               AVG(sp.SENTIMENT_SCORE) AS AVG_SENTIMENT,
               AVG(sp.VIRALITY_SCORE) AS AVG_VIRALITY
        FROM POST_PRODUCT_MENTIONS ppm
        JOIN SOCIAL_POSTS sp ON ppm.POST_ID = sp.POST_ID
        GROUP BY ppm.PRODUCT_ID
      ) eng ON p.PRODUCT_ID = eng.PRODUCT_ID
      WHERE p.IS_ACTIVE = 1
    )`;
}

async function fallbackVectorClusters({ k }) {
  const result = await db.execute(`
    ${buildProductClusterFeaturesCte()}
    , scored_products AS (
      SELECT
        pcf.*,
        ROUND(
          NVL(pcf.PRODUCT_REVENUE, 0) * 0.001 +
          NVL(pcf.UNITS_SOLD, 0) * 0.8 +
          NVL(pcf.TOTAL_ENGAGEMENT, 0) * 0.0005 +
          NVL(pcf.AVG_VIRALITY, 0) * 3 +
          NVL(pcf.UNIT_PRICE, 0) * 0.05,
        4) AS COMPOSITE_SCORE,
        NTILE(${k}) OVER (
          ORDER BY NVL(pcf.TOTAL_ENGAGEMENT, 0) DESC,
                   NVL(pcf.UNITS_SOLD, 0) DESC,
                   NVL(pcf.PRODUCT_REVENUE, 0) DESC,
                   pcf.PRODUCT_ID
        ) AS CLUSTER_ID
      FROM product_cluster_features pcf
    ),
    ranked_products AS (
      SELECT
        sp.*,
        FIRST_VALUE(sp.PRODUCT_NAME) OVER (
          PARTITION BY sp.CLUSTER_ID
          ORDER BY sp.COMPOSITE_SCORE DESC, sp.PRODUCT_ID
        ) AS SEED_NAME,
        FIRST_VALUE(sp.PRODUCT_ID) OVER (
          PARTITION BY sp.CLUSTER_ID
          ORDER BY sp.COMPOSITE_SCORE DESC, sp.PRODUCT_ID
        ) AS SEED_ID,
        MAX(sp.COMPOSITE_SCORE) OVER (PARTITION BY sp.CLUSTER_ID) AS MAX_SCORE,
        MIN(sp.COMPOSITE_SCORE) OVER (PARTITION BY sp.CLUSTER_ID) AS MIN_SCORE
      FROM scored_products sp
    )
    SELECT
      rp.PRODUCT_ID,
      rp.CLUSTER_ID,
      ROUND(
        CASE
          WHEN rp.MAX_SCORE = rp.MIN_SCORE THEN 1
          ELSE 0.5 + 0.5 * ((rp.COMPOSITE_SCORE - rp.MIN_SCORE) / NULLIF(rp.MAX_SCORE - rp.MIN_SCORE, 0))
        END,
      4) AS SIMILARITY,
      rp.PRODUCT_NAME,
      rp.CATEGORY,
      rp.UNIT_PRICE,
      rp.BRAND_NAME,
      rp.UNITS_SOLD,
      rp.TOTAL_ENGAGEMENT,
      rp.SEED_NAME,
      rp.SEED_ID
    FROM ranked_products rp
    ORDER BY rp.CLUSTER_ID, SIMILARITY DESC, rp.PRODUCT_ID
  `);

  const clusterMap = {};
  result.rows.forEach(r => {
    const cid = r.CLUSTER_ID;
    if (!clusterMap[cid]) {
      clusterMap[cid] = {
        cluster_id: cid,
        centroid_product: r.SEED_NAME,
        centroid_product_id: r.SEED_ID,
        products: [],
        categories: {},
        total_similarity: 0,
      };
    }
    const cl = clusterMap[cid];
    cl.products.push({
      product_id: r.PRODUCT_ID,
      product_name: r.PRODUCT_NAME,
      category: r.CATEGORY,
      brand_name: r.BRAND_NAME,
      unit_price: r.UNIT_PRICE,
      similarity: r.SIMILARITY,
      is_centroid: r.PRODUCT_ID === r.SEED_ID,
    });
    cl.categories[r.CATEGORY] = (cl.categories[r.CATEGORY] || 0) + 1;
    cl.total_similarity += Number(r.SIMILARITY) || 0;
  });

  const clusters = Object.values(clusterMap).map(cl => ({
    cluster_id: cl.cluster_id,
    centroid_product: cl.centroid_product,
    size: cl.products.length,
    avg_similarity: Math.round((cl.total_similarity / cl.products.length) * 10000) / 10000,
    top_category: Object.entries(cl.categories).sort((a, b) => b[1] - a[1])[0]?.[0] || '',
    category_breakdown: cl.categories,
    products: cl.products,
  }));

  return {
    k,
    total_products: result.rows.length,
    clusters,
    meta: {
      model: `Quantile clustering fallback (${k} buckets)`,
      algorithm: 'NTILE + weighted product score',
      scoring: 'Window-function clustering with centroid by composite score',
      features: ['unit_price', 'units_sold', 'revenue', 'total_engagement', 'avg_sentiment', 'avg_virality'],
      engine: 'Oracle SQL fallback - persisted DBMS_DATA_MINING model/view not available',
      fallback: true,
    },
  };
}

async function fallbackInventoryIntelligence() {
  const result = await db.execute(`
    ${buildDemandProductFeaturesCte('720')}
    , scored_products AS (
      SELECT pf.PRODUCT_ID,
             ${heuristicSurgeProbabilitySql('pf')} AS SURGE_PROBABILITY
      FROM product_features pf
    )
    SELECT
      p.PRODUCT_ID,
      p.PRODUCT_NAME,
      p.CATEGORY,
      p.UNIT_PRICE,
      b.BRAND_NAME,
      fc.CENTER_ID,
      fc.SERVICE_REGION_CODE,
      fc.CENTER_NAME,
      fc.CITY,
      fc.STATE_PROVINCE,
      i.QUANTITY_ON_HAND,
      i.REORDER_POINT,
      i.QUANTITY_RESERVED,
      i.QUANTITY_ON_HAND - i.REORDER_POINT AS DEFICIT,
      NVL(df.PREDICTED_DEMAND, 0) AS PREDICTED_DEMAND,
      NVL(df.SOCIAL_FACTOR, 1.0) AS SOCIAL_FACTOR,
      NVL(df.CONFIDENCE_LOW, 0) AS CONFIDENCE_LOW,
      NVL(df.CONFIDENCE_HIGH, 0) AS CONFIDENCE_HIGH,
      df.MODEL_VERSION,
      CASE
        WHEN NVL(sp.SURGE_PROBABILITY, 0) >= 65 THEN 'SURGE'
        WHEN NVL(sp.SURGE_PROBABILITY, 0) >= 45 THEN 'WATCH'
        ELSE 'STABLE'
      END AS OML_SURGE_PREDICTION,
      NVL(sp.SURGE_PROBABILITY, 0) AS OML_SURGE_PROBABILITY,
      CASE
        WHEN i.QUANTITY_ON_HAND = 0 THEN 'OUT_OF_STOCK'
        WHEN i.QUANTITY_ON_HAND < i.REORDER_POINT * 0.5 THEN 'CRITICAL'
        WHEN i.QUANTITY_ON_HAND < i.REORDER_POINT THEN 'LOW'
        WHEN i.QUANTITY_ON_HAND < NVL(df.PREDICTED_DEMAND, i.REORDER_POINT) THEN 'AT_RISK'
        ELSE 'ADEQUATE'
      END AS STOCK_STATUS,
      CASE
        WHEN NVL(df.PREDICTED_DEMAND, 0) > 0 THEN ROUND(i.QUANTITY_ON_HAND / (df.PREDICTED_DEMAND / 7), 1)
        ELSE NULL
      END AS DAYS_OF_SUPPLY,
      CASE
        WHEN i.QUANTITY_ON_HAND < NVL(df.PREDICTED_DEMAND, 0)
          THEN ROUND((NVL(df.PREDICTED_DEMAND, 0) - i.QUANTITY_ON_HAND) * p.UNIT_PRICE, 2)
        ELSE 0
      END AS REVENUE_AT_RISK
    FROM INVENTORY i
    JOIN PRODUCTS p ON i.PRODUCT_ID = p.PRODUCT_ID
    JOIN BRANDS b ON p.BRAND_ID = b.BRAND_ID
    JOIN FULFILLMENT_CENTERS fc ON i.CENTER_ID = fc.CENTER_ID
    LEFT JOIN DEMAND_FORECASTS df
      ON p.PRODUCT_ID = df.PRODUCT_ID
     AND df.FORECAST_DATE = TRUNC(SYSDATE)
    LEFT JOIN scored_products sp ON p.PRODUCT_ID = sp.PRODUCT_ID
    WHERE fc.IS_ACTIVE = 1
    ORDER BY NVL(sp.SURGE_PROBABILITY, 0) DESC, i.QUANTITY_ON_HAND ASC
    FETCH FIRST 100 ROWS ONLY
  `);

  const alerts = result.rows;
  const critical = alerts.filter(a => a.STOCK_STATUS === 'CRITICAL' || a.STOCK_STATUS === 'OUT_OF_STOCK').length;
  const atRisk = alerts.filter(a => a.STOCK_STATUS === 'AT_RISK').length;
  const surgeProducts = alerts.filter(a => a.OML_SURGE_PREDICTION === 'SURGE').length;
  const totalRevenueAtRisk = alerts.reduce((sum, a) => sum + (Number(a.REVENUE_AT_RISK) || 0), 0);

  const statusDist = {};
  alerts.forEach(a => {
    statusDist[a.STOCK_STATUS] = (statusDist[a.STOCK_STATUS] || 0) + 1;
  });

  const centerMap = {};
  alerts.forEach(a => {
    if (!centerMap[a.CENTER_NAME]) {
      centerMap[a.CENTER_NAME] = { center: a.CENTER_NAME, city: a.CITY, alerts: 0, critical: 0, surges: 0 };
    }
    centerMap[a.CENTER_NAME].alerts++;
    if (a.STOCK_STATUS === 'CRITICAL' || a.STOCK_STATUS === 'OUT_OF_STOCK') centerMap[a.CENTER_NAME].critical++;
    if (a.OML_SURGE_PREDICTION === 'SURGE') centerMap[a.CENTER_NAME].surges++;
  });

  return {
    alerts,
    summary: {
      total_alerts: alerts.length,
      critical_count: critical,
      at_risk_count: atRisk,
      surge_products: surgeProducts,
      total_revenue_at_risk: Math.round(totalRevenueAtRisk * 100) / 100,
    },
    statusDistribution: Object.entries(statusDist).map(([status, count]) => ({ status, count })),
    centerSummary: Object.values(centerMap).sort((a, b) => b.critical - a.critical),
    meta: {
      model: 'Demand signal heuristic + demand_forecasts (fallback)',
      scoring: 'Weighted social signal + inventory JOIN',
      engine: 'Oracle SQL fallback - persisted DBMS_DATA_MINING model not available',
      fallback: true,
    },
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// GET /api/ml/demand-forecast
//
// Scores products using the DEMAND_SURGE_MODEL (Random Forest, 50 trees).
// Training features: social engagement, virality, likes, shares, views, sales.
// Returns PREDICTION() label + PREDICTION_PROBABILITY() confidence.
// ─────────────────────────────────────────────────────────────────────────────
router.get('/demand-forecast', async (req, res) => {
  try {
    const limit = Math.min(parseInt(req.query.limit) || 20, 50);
    const lookbackHours = Math.min(parseInt(req.query.hours) || 720, 2160);
    try {
      return res.json(await getPersistedDemandForecast({ limit, lookbackHours }));
    } catch (persistErr) {
      console.warn('Persisted demand forecast unavailable; falling back to live scoring:', persistErr.message);
    }

    const result = await db.execute(`
      WITH product_features AS (
        SELECT /*+ NO_PARALLEL */
               p.product_id,
               p.product_name,
               p.category,
               b.brand_name,
               b.social_tier,
               p.unit_price,
               NVL(eng.TOTAL_POSTS, 0)      AS total_posts,
               NVL(eng.AVG_SENTIMENT, 0.5)   AS avg_sentiment,
               NVL(eng.TOTAL_LIKES, 0)       AS total_likes,
               NVL(eng.TOTAL_SHARES, 0)      AS total_shares,
               NVL(eng.TOTAL_VIEWS, 0)       AS total_views,
               NVL(eng.AVG_VIRALITY, 0)      AS avg_virality,
               NVL(eng.VIRAL_POSTS, 0)       AS viral_posts,
               NVL(eng.RISING_POSTS, 0)      AS rising_posts,
               NVL(sales.UNITS_SOLD, 0)      AS units_sold,
               NVL(sales.REVENUE, 0)         AS revenue,
               eng.PEAK_MOMENTUM
        FROM products p
        JOIN brands b ON b.brand_id = p.brand_id
        LEFT JOIN (
            SELECT ppm.PRODUCT_ID,
                   COUNT(*) AS TOTAL_POSTS,
                   AVG(sp.SENTIMENT_SCORE) AS AVG_SENTIMENT,
                   SUM(sp.LIKES_COUNT) AS TOTAL_LIKES,
                   SUM(sp.SHARES_COUNT) AS TOTAL_SHARES,
                   SUM(sp.VIEWS_COUNT) AS TOTAL_VIEWS,
                   AVG(sp.VIRALITY_SCORE) AS AVG_VIRALITY,
                   SUM(CASE WHEN sp.MOMENTUM_FLAG = 'viral' THEN 1 ELSE 0 END) AS VIRAL_POSTS,
                   SUM(CASE WHEN sp.MOMENTUM_FLAG = 'rising' THEN 1 ELSE 0 END) AS RISING_POSTS,
                   MAX(sp.MOMENTUM_FLAG) AS PEAK_MOMENTUM
            FROM POST_PRODUCT_MENTIONS ppm
            JOIN SOCIAL_POSTS sp ON ppm.POST_ID = sp.POST_ID
            WHERE CAST(sp.POSTED_AT AS DATE) >= SYSDATE - :lookback / 24
            GROUP BY ppm.PRODUCT_ID
        ) eng ON p.PRODUCT_ID = eng.PRODUCT_ID
        LEFT JOIN (
            SELECT oi.PRODUCT_ID,
                   SUM(oi.QUANTITY) AS UNITS_SOLD,
                   SUM(oi.LINE_TOTAL) AS REVENUE
            FROM ORDER_ITEMS oi
            JOIN ORDERS o ON o.ORDER_ID = oi.ORDER_ID
            WHERE CAST(o.CREATED_AT AS DATE) >= SYSDATE - :lookback / 24
            GROUP BY oi.PRODUCT_ID
        ) sales ON p.PRODUCT_ID = sales.PRODUCT_ID
        WHERE p.IS_ACTIVE = 1
          AND (eng.PRODUCT_ID IS NOT NULL OR sales.PRODUCT_ID IS NOT NULL)
      )
      SELECT
        pf.product_id,
        pf.product_name,
        pf.category,
        pf.brand_name,
        pf.social_tier,
        pf.unit_price,
        pf.total_posts      AS recent_mentions,
        ROUND(pf.avg_virality, 1) AS avg_virality,
        pf.total_likes,
        pf.total_shares,
        pf.total_views,
        pf.units_sold        AS orders_recent,
        pf.peak_momentum,

        -- Oracle DBMS_DATA_MINING: Random Forest scoring
        PREDICTION(DEMAND_SURGE_MODEL USING
          pf.category       AS category,
          pf.unit_price     AS unit_price,
          pf.total_posts    AS total_posts,
          pf.avg_sentiment  AS avg_sentiment,
          pf.total_likes    AS total_likes,
          pf.total_shares   AS total_shares,
          pf.total_views    AS total_views,
          pf.avg_virality   AS avg_virality,
          pf.viral_posts    AS viral_posts,
          pf.rising_posts   AS rising_posts,
          pf.units_sold     AS units_sold,
          pf.revenue        AS revenue
        ) AS predicted_surge,

        ROUND(PREDICTION_PROBABILITY(DEMAND_SURGE_MODEL, 'SURGE' USING
          pf.category       AS category,
          pf.unit_price     AS unit_price,
          pf.total_posts    AS total_posts,
          pf.avg_sentiment  AS avg_sentiment,
          pf.total_likes    AS total_likes,
          pf.total_shares   AS total_shares,
          pf.total_views    AS total_views,
          pf.avg_virality   AS avg_virality,
          pf.viral_posts    AS viral_posts,
          pf.rising_posts   AS rising_posts,
          pf.units_sold     AS units_sold,
          pf.revenue        AS revenue
        ) * 100, 1) AS surge_probability,

        -- Predicted demand: units × probability-weighted multiplier
        GREATEST(0, ROUND(
          pf.units_sold * (1 + PREDICTION_PROBABILITY(DEMAND_SURGE_MODEL, 'SURGE' USING
            pf.category AS category, pf.unit_price AS unit_price,
            pf.total_posts AS total_posts, pf.avg_sentiment AS avg_sentiment,
            pf.total_likes AS total_likes, pf.total_shares AS total_shares,
            pf.total_views AS total_views, pf.avg_virality AS avg_virality,
            pf.viral_posts AS viral_posts, pf.rising_posts AS rising_posts,
            pf.units_sold AS units_sold, pf.revenue AS revenue
          ) * 2.5)
          + pf.total_posts * 0.5
        , 0)) AS predicted_demand,

        -- Uplift % based on surge probability
        ROUND(PREDICTION_PROBABILITY(DEMAND_SURGE_MODEL, 'SURGE' USING
          pf.category AS category, pf.unit_price AS unit_price,
          pf.total_posts AS total_posts, pf.avg_sentiment AS avg_sentiment,
          pf.total_likes AS total_likes, pf.total_shares AS total_shares,
          pf.total_views AS total_views, pf.avg_virality AS avg_virality,
          pf.viral_posts AS viral_posts, pf.rising_posts AS rising_posts,
          pf.units_sold AS units_sold, pf.revenue AS revenue
        ) * 100, 1) AS uplift_pct,

        -- Confidence = surge probability
        ROUND(PREDICTION_PROBABILITY(DEMAND_SURGE_MODEL, 'SURGE' USING
          pf.category AS category, pf.unit_price AS unit_price,
          pf.total_posts AS total_posts, pf.avg_sentiment AS avg_sentiment,
          pf.total_likes AS total_likes, pf.total_shares AS total_shares,
          pf.total_views AS total_views, pf.avg_virality AS avg_virality,
          pf.viral_posts AS viral_posts, pf.rising_posts AS rising_posts,
          pf.units_sold AS units_sold, pf.revenue AS revenue
        ) * 100, 0) AS confidence_pct,

        -- Revenue opportunity
        GREATEST(0, ROUND(
          (pf.units_sold * (1 + PREDICTION_PROBABILITY(DEMAND_SURGE_MODEL, 'SURGE' USING
            pf.category AS category, pf.unit_price AS unit_price,
            pf.total_posts AS total_posts, pf.avg_sentiment AS avg_sentiment,
            pf.total_likes AS total_likes, pf.total_shares AS total_shares,
            pf.total_views AS total_views, pf.avg_virality AS avg_virality,
            pf.viral_posts AS viral_posts, pf.rising_posts AS rising_posts,
            pf.units_sold AS units_sold, pf.revenue AS revenue
          ) * 2.5) + pf.total_posts * 0.5)
          * pf.unit_price
        , 2)) AS revenue_opportunity

      FROM product_features pf
      WHERE pf.total_posts > 0 OR pf.units_sold > 0
      ORDER BY surge_probability DESC, avg_virality DESC
      FETCH FIRST :limit ROWS ONLY
    `, { lookback: lookbackHours, limit });

    res.json({
      products: result.rows,
      meta: {
        lookback_hours: lookbackHours,
        model: 'DEMAND_SURGE_MODEL (Random Forest, 50 trees)',
        algorithm: 'ALGO_RANDOM_FOREST',
        scoring: 'PREDICTION() / PREDICTION_PROBABILITY()',
        features: ['category', 'unit_price', 'total_posts', 'avg_sentiment', 'total_likes',
                   'total_shares', 'total_views', 'avg_virality', 'viral_posts', 'rising_posts',
                   'units_sold', 'revenue'],
        engine: 'Oracle DBMS_DATA_MINING - in-database Random Forest',
      },
    });
  } catch (err) {
    const limit = Math.min(parseInt(req.query.limit) || 20, 50);
    const lookbackHours = Math.min(parseInt(req.query.hours) || 720, 2160);
    return handleMlRouteError(res, 'ML demand-forecast', err, () =>
      fallbackDemandForecast({ limit, lookbackHours })
    );
  }
});


// ─────────────────────────────────────────────────────────────────────────────
// GET /api/ml/customer-segments
//
// Scores customers using CUSTOMER_SEGMENT_MODEL (K-Means, 4 clusters).
// Training features: lifetime_value, recency_days, frequency, monetary, avg_order_value.
// Returns CLUSTER_ID() assignment + CLUSTER_PROBABILITY() confidence.
// Also computes RFM quartiles via NTILE for labeling.
// ─────────────────────────────────────────────────────────────────────────────
router.get('/customer-segments', async (req, res) => {
  try {
    const limit = Math.min(parseInt(req.query.limit) || 200, 1000);
    try {
      return res.json(await getPersistedCustomerSegments({ limit }));
    } catch (persistErr) {
      console.warn('Persisted resident need segments unavailable; falling back to live scoring:', persistErr.message);
    }

    const result = await db.execute(`
      WITH customer_metrics AS (
        SELECT /*+ NO_PARALLEL */
               c.customer_id,
               c.first_name || ' ' || c.last_name              AS full_name,
               c.city,
               c.state_province                                  AS state,
               c.service_region_code,
               c.lifetime_value,
               NVL(rfm.RECENCY_DAYS, 999)                       AS recency_days,
               NVL(rfm.FREQUENCY, 0)                             AS frequency,
               NVL(rfm.MONETARY, 0)                              AS monetary,
               NVL(rfm.AVG_ORDER_VALUE, 0)                       AS avg_order_value,
               NVL(rfm.TOTAL_ITEMS, 0)                           AS total_items,
               rfm.FREQUENCY                                     AS order_count,
               rfm.MONETARY                                      AS total_spent,
               rfm.RECENCY_DAYS                                  AS days_since_last_order
        FROM customers c
        LEFT JOIN (
            SELECT o.CUSTOMER_ID,
                   ROUND(SYSDATE - CAST(MAX(o.CREATED_AT) AS DATE)) AS RECENCY_DAYS,
                   COUNT(DISTINCT o.ORDER_ID) AS FREQUENCY,
                   SUM(o.ORDER_TOTAL) AS MONETARY,
                   AVG(o.ORDER_TOTAL) AS AVG_ORDER_VALUE,
                   NVL(SUM(oi_cnt.ITEM_COUNT), 0) AS TOTAL_ITEMS
            FROM ORDERS o
            LEFT JOIN (
                SELECT ORDER_ID, SUM(QUANTITY) AS ITEM_COUNT
                FROM ORDER_ITEMS GROUP BY ORDER_ID
            ) oi_cnt ON o.ORDER_ID = oi_cnt.ORDER_ID
            GROUP BY o.CUSTOMER_ID
        ) rfm ON c.CUSTOMER_ID = rfm.CUSTOMER_ID
      )
      SELECT
        cm.customer_id,
        cm.full_name,
        cm.city,
        cm.state,
        cm.service_region_code,
        NVL(cm.order_count, 0)          AS order_count,
        ROUND(NVL(cm.total_spent, 0), 2) AS total_spent,
        ROUND(cm.avg_order_value, 2)     AS avg_order_value,
        NVL(cm.days_since_last_order, 999) AS days_since_last_order,

        -- Oracle DBMS_DATA_MINING: K-Means cluster assignment
        CLUSTER_ID(CUSTOMER_SEGMENT_MODEL USING
          cm.lifetime_value  AS lifetime_value,
          cm.recency_days    AS recency_days,
          cm.frequency       AS frequency,
          cm.monetary        AS monetary,
          cm.avg_order_value AS avg_order_value,
          cm.total_items     AS total_items
        ) AS oml_cluster_id,

        ROUND(CLUSTER_PROBABILITY(CUSTOMER_SEGMENT_MODEL USING
          cm.lifetime_value  AS lifetime_value,
          cm.recency_days    AS recency_days,
          cm.frequency       AS frequency,
          cm.monetary        AS monetary,
          cm.avg_order_value AS avg_order_value,
          cm.total_items     AS total_items
        ), 3) AS cluster_probability,

        -- RFM quartile scores for labeling
        NTILE(4) OVER (ORDER BY cm.recency_days ASC)   AS recency_score,
        NTILE(4) OVER (ORDER BY cm.frequency DESC)     AS frequency_score,
        NTILE(4) OVER (ORDER BY cm.monetary DESC)      AS monetary_score,

        -- Segment label derived from OML cluster + RFM
        CASE
          WHEN NTILE(4) OVER (ORDER BY cm.recency_days ASC) = 4
           AND NTILE(4) OVER (ORDER BY cm.frequency DESC) >= 3
           AND NTILE(4) OVER (ORDER BY cm.monetary DESC) >= 3 THEN 'Champion'
          WHEN NTILE(4) OVER (ORDER BY cm.recency_days ASC) >= 3
           AND NTILE(4) OVER (ORDER BY cm.frequency DESC) >= 3 THEN 'Loyal'
          WHEN NTILE(4) OVER (ORDER BY cm.recency_days ASC) = 4
           AND NTILE(4) OVER (ORDER BY cm.frequency DESC) <= 2 THEN 'New Customer'
          WHEN NTILE(4) OVER (ORDER BY cm.recency_days ASC) <= 2
           AND NTILE(4) OVER (ORDER BY cm.monetary DESC) = 4 THEN 'At Risk'
          WHEN NTILE(4) OVER (ORDER BY cm.recency_days ASC) = 1
           AND NTILE(4) OVER (ORDER BY cm.frequency DESC) <= 2 THEN 'Lost'
          WHEN NTILE(4) OVER (ORDER BY cm.monetary DESC) = 4
           AND NTILE(4) OVER (ORDER BY cm.recency_days ASC) >= 2 THEN 'Big Spender'
          WHEN NTILE(4) OVER (ORDER BY cm.recency_days ASC) >= 3
           AND NTILE(4) OVER (ORDER BY cm.monetary DESC) <= 2 THEN 'Promising'
          ELSE 'Potential'
        END AS segment,

        -- Churn risk
        CASE
          WHEN NVL(cm.days_since_last_order, 999) > 60 THEN 'High'
          WHEN NVL(cm.days_since_last_order, 999) > 30 THEN 'Medium'
          ELSE 'Low'
        END AS churn_risk,

        -- Predicted LTV
        ROUND(cm.avg_order_value * GREATEST(1,
          NVL(cm.frequency, 0) / NULLIF(cm.recency_days, 0) * 365
        ), 2) AS predicted_ltv

      FROM customer_metrics cm
      WHERE cm.frequency > 0
      ORDER BY total_spent DESC
      FETCH FIRST :limit ROWS ONLY
    `, { limit });

    // Roll up segment counts
    const segMap = {};
    result.rows.forEach(r => {
      const seg = r.SEGMENT;
      if (!segMap[seg]) {
        segMap[seg] = { segment: seg, count: 0, total_revenue: 0, avg_rfm: 0, churn_high: 0 };
      }
      segMap[seg].count++;
      segMap[seg].total_revenue += Number(r.TOTAL_SPENT) || 0;
      segMap[seg].avg_rfm += (Number(r.RECENCY_SCORE) || 0) + (Number(r.FREQUENCY_SCORE) || 0) + (Number(r.MONETARY_SCORE) || 0);
      if (r.CHURN_RISK === 'High') segMap[seg].churn_high++;
    });

    const segmentSummary = Object.values(segMap).map(s => ({
      ...s,
      total_revenue: Math.round(s.total_revenue * 100) / 100,
      avg_rfm: Math.round((s.avg_rfm / s.count) * 10) / 10,
    })).sort((a, b) => b.count - a.count);

    const churnDist = { High: 0, Medium: 0, Low: 0 };
    result.rows.forEach(r => { churnDist[r.CHURN_RISK] = (churnDist[r.CHURN_RISK] || 0) + 1; });

    res.json({
      customers: result.rows,
      segmentSummary,
      churnDistribution: Object.entries(churnDist).map(([risk, count]) => ({ risk, count })),
      total: result.rows.length,
      meta: {
        model: 'CUSTOMER_SEGMENT_MODEL (K-Means, 4 clusters)',
        algorithm: 'ALGO_KMEANS',
        scoring: 'CLUSTER_ID() / CLUSTER_PROBABILITY()',
        dimensions: ['lifetime_value', 'recency_days', 'frequency', 'monetary', 'avg_order_value', 'total_items'],
        engine: 'Oracle DBMS_DATA_MINING - in-database K-Means Clustering',
        clusters: segmentSummary.length,
      },
    });
  } catch (err) {
    const limit = Math.min(parseInt(req.query.limit) || 200, 1000);
    return handleMlRouteError(res, 'ML customer-segments', err, () =>
      fallbackCustomerSegments({ limit })
    );
  }
});


// ─────────────────────────────────────────────────────────────────────────────
// GET /api/ml/revenue-forecast
//
// Time-series revenue forecast using:
//   1. Oracle REGR_SLOPE/REGR_INTERCEPT/REGR_R2 for trend fitting
//   2. REVENUE_PREDICT_MODEL (GLM Regression) for per-order predictions
// ─────────────────────────────────────────────────────────────────────────────
router.get('/revenue-forecast', async (req, res) => {
  try {
    const lookbackDays = Math.min(parseInt(req.query.days) || 30, 90);
    const forecastDays = Math.min(parseInt(req.query.forecast) || 7, 14);
    try {
      return res.json(await getPersistedCommitmentForecast({ lookbackDays, forecastDays }));
    } catch (persistErr) {
      console.warn('Persisted service value forecast unavailable; falling back to live scoring:', persistErr.message);
    }

    const histResult = await db.execute(`
      WITH daily_rev AS (
        SELECT /*+ NO_PARALLEL */
               TRUNC(CAST(created_at AS DATE), 'DD')            AS day_bucket,
               SUM(order_total)                                  AS revenue,
               COUNT(order_id)                                   AS order_count,
               AVG(order_total)                                  AS avg_order_value,
               ROW_NUMBER() OVER (
                 ORDER BY TRUNC(CAST(created_at AS DATE), 'DD')
               )                                                 AS rn
        FROM   orders
        WHERE  CAST(created_at AS DATE) >= SYSDATE - :lookback
        GROUP  BY TRUNC(CAST(created_at AS DATE), 'DD')
      ),
      params AS (
        SELECT
          REGR_SLOPE(revenue, rn)                                AS slope,
          REGR_INTERCEPT(revenue, rn)                            AS intercept,
          REGR_R2(revenue, rn)                                   AS r2,
          REGR_COUNT(revenue, rn)                                AS n_obs,
          AVG(revenue)                                           AS mean_revenue,
          STDDEV(revenue)                                        AS stddev_revenue,
          MAX(rn)                                                AS max_rn,
          CORR(revenue, rn)                                      AS correlation
        FROM daily_rev
      ),
      -- Oracle GLM model: predicted revenue per order
      glm_stats AS (
        SELECT
          ROUND(AVG(PREDICTION(REVENUE_PREDICT_MODEL USING *)), 2) AS avg_glm_predicted,
          ROUND(CORR(TARGET_REVENUE, PREDICTION(REVENUE_PREDICT_MODEL USING *)), 4) AS glm_correlation
        FROM OML_REVENUE_TRAINING_V
        WHERE ROWNUM <= 500
      )
      SELECT
        TO_CHAR(d.day_bucket, 'YYYY-MM-DD')                     AS day,
        ROUND(d.revenue, 2)                                      AS actual_revenue,
        d.order_count,
        ROUND(d.avg_order_value, 2)                              AS avg_order_value,
        ROUND(p.slope * d.rn + p.intercept, 2)                  AS trend_line,
        ROUND(AVG(d.revenue) OVER (
          ORDER BY d.rn ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
        ), 2)                                                    AS ma_7d,
        ROUND(p.r2, 4)                                           AS r_squared,
        ROUND(p.slope, 2)                                        AS daily_slope,
        ROUND(p.intercept, 2)                                    AS intercept,
        ROUND(p.mean_revenue, 2)                                 AS mean_revenue,
        ROUND(p.stddev_revenue, 2)                               AS stddev_revenue,
        ROUND(p.correlation, 4)                                  AS correlation,
        p.max_rn                                                 AS max_rn,
        g.avg_glm_predicted,
        g.glm_correlation,
        0                                                        AS is_forecast
      FROM   daily_rev d
      CROSS JOIN params p
      CROSS JOIN glm_stats g
      ORDER  BY d.day_bucket
    `, { lookback: lookbackDays });

    if (!histResult.rows.length) {
      return res.json({ historical: [], forecast: [], model: null });
    }

    const last = histResult.rows[histResult.rows.length - 1];
    const slope      = Number(last.DAILY_SLOPE)     || 0;
    const intercept  = Number(last.INTERCEPT)       || 0;
    const maxRn      = Number(last.MAX_RN)          || 0;
    const stddev     = Number(last.STDDEV_REVENUE)  || 0;

    const forecast = [];
    for (let i = 1; i <= forecastDays; i++) {
      const futureRn = maxRn + i;
      const predicted = Math.max(0, slope * futureRn + intercept);
      const ci = stddev * (1 + i * 0.07);
      const d = new Date();
      d.setDate(d.getDate() + i);

      forecast.push({
        DAY: d.toISOString().slice(0, 10),
        ACTUAL_REVENUE: null,
        ORDER_COUNT: null,
        AVG_ORDER_VALUE: null,
        TREND_LINE: Math.round(predicted * 100) / 100,
        MA_7D: null,
        CI_LOWER: Math.round(Math.max(0, predicted - ci) * 100) / 100,
        CI_UPPER: Math.round((predicted + ci) * 100) / 100,
        IS_FORECAST: 1,
      });
    }

    res.json({
      historical: histResult.rows,
      forecast,
      model: {
        type: 'GLM Regression (REVENUE_PREDICT_MODEL) + OLS Trend (REGR_SLOPE)',
        algorithm: 'ALGO_GENERALIZED_LINEAR_MODEL',
        engine: 'Oracle DBMS_DATA_MINING + REGR_SLOPE / REGR_R2',
        r_squared: Number(last.R_SQUARED),
        correlation: Number(last.CORRELATION),
        glm_correlation: Number(last.GLM_CORRELATION),
        avg_glm_predicted: Number(last.AVG_GLM_PREDICTED),
        daily_slope: slope,
        intercept,
        mean_daily_revenue: Number(last.MEAN_REVENUE),
        stddev: stddev,
        observations: maxRn,
        lookback_days: lookbackDays,
        forecast_days: forecastDays,
      },
    });
  } catch (err) {
    const lookbackDays = Math.min(parseInt(req.query.days) || 30, 90);
    const forecastDays = Math.min(parseInt(req.query.forecast) || 7, 14);
    return handleMlRouteError(res, 'ML revenue-forecast', err, () =>
      fallbackRevenueForecast({ lookbackDays, forecastDays })
    );
  }
});


// ─────────────────────────────────────────────────────────────────────────────
// GET /api/ml/summary
// Quick stats for all four OML models
// ─────────────────────────────────────────────────────────────────────────────
router.get('/summary', async (req, res) => {
  try {
    const [surgeCount, customers, segmentCount, modelCount, regr] = await Promise.all([
      // Count products predicted as SURGE by the Random Forest model
      db.execute(`
        SELECT COUNT(*) AS cnt FROM (
          SELECT p.PRODUCT_ID,
            PREDICTION(DEMAND_SURGE_MODEL USING
              p.CATEGORY AS category, p.UNIT_PRICE AS unit_price,
              NVL(eng.TOTAL_POSTS, 0) AS total_posts,
              NVL(eng.AVG_SENTIMENT, 0.5) AS avg_sentiment,
              NVL(eng.TOTAL_LIKES, 0) AS total_likes,
              NVL(eng.TOTAL_SHARES, 0) AS total_shares,
              NVL(eng.TOTAL_VIEWS, 0) AS total_views,
              NVL(eng.AVG_VIRALITY, 0) AS avg_virality,
              NVL(eng.VIRAL_POSTS, 0) AS viral_posts,
              NVL(eng.RISING_POSTS, 0) AS rising_posts,
              NVL(sales.UNITS_SOLD, 0) AS units_sold,
              NVL(sales.REVENUE, 0) AS revenue
            ) AS pred
          FROM PRODUCTS p
          LEFT JOIN (
              SELECT ppm.PRODUCT_ID,
                     COUNT(*) AS TOTAL_POSTS, AVG(sp.SENTIMENT_SCORE) AS AVG_SENTIMENT,
                     SUM(sp.LIKES_COUNT) AS TOTAL_LIKES, SUM(sp.SHARES_COUNT) AS TOTAL_SHARES,
                     SUM(sp.VIEWS_COUNT) AS TOTAL_VIEWS, AVG(sp.VIRALITY_SCORE) AS AVG_VIRALITY,
                     SUM(CASE WHEN sp.MOMENTUM_FLAG='viral' THEN 1 ELSE 0 END) AS VIRAL_POSTS,
                     SUM(CASE WHEN sp.MOMENTUM_FLAG='rising' THEN 1 ELSE 0 END) AS RISING_POSTS
              FROM POST_PRODUCT_MENTIONS ppm
              JOIN SOCIAL_POSTS sp ON ppm.POST_ID = sp.POST_ID
              WHERE CAST(sp.POSTED_AT AS DATE) >= SYSDATE - 30
              GROUP BY ppm.PRODUCT_ID
          ) eng ON p.PRODUCT_ID = eng.PRODUCT_ID
          LEFT JOIN (
              SELECT PRODUCT_ID, SUM(QUANTITY) AS UNITS_SOLD, SUM(LINE_TOTAL) AS REVENUE
              FROM ORDER_ITEMS GROUP BY PRODUCT_ID
          ) sales ON p.PRODUCT_ID = sales.PRODUCT_ID
          WHERE p.IS_ACTIVE = 1
            AND (eng.PRODUCT_ID IS NOT NULL OR sales.PRODUCT_ID IS NOT NULL)
        ) WHERE pred = 'SURGE'
      `),
      db.execute(`SELECT COUNT(*) AS cnt FROM customers`),
      db.execute(`
        WITH persisted_segments AS (
          SELECT COUNT(DISTINCT segment) AS cnt
          FROM oml_customer_segments
          WHERE run_id = (SELECT MAX(run_id) FROM oml_customer_segments)
        ),
        resident_metrics AS (
          SELECT c.customer_id,
                 COUNT(o.order_id) AS request_count,
                 NVL(SUM(o.order_total), 0) AS service_value
          FROM customers c
          LEFT JOIN orders o ON o.customer_id = c.customer_id
          GROUP BY c.customer_id
        ),
        live_segments AS (
          SELECT COUNT(DISTINCT CASE
                   WHEN request_count >= 5 AND service_value >= 5000 THEN 'High Need / High Activity'
                   WHEN request_count >= 5 THEN 'Frequent Service User'
                   WHEN service_value >= 5000 THEN 'High Value Exposure'
                   WHEN request_count > 0 THEN 'Standard Support'
                 END) AS cnt
          FROM resident_metrics
          WHERE request_count > 0
        )
        SELECT CASE WHEN persisted_segments.cnt > 0
                    THEN persisted_segments.cnt
                    ELSE live_segments.cnt
               END AS cnt
        FROM persisted_segments CROSS JOIN live_segments
      `),
      // Mining model metadata is global-only technical state.
      db.execute(`
        SELECT CASE
                 WHEN SYS_CONTEXT('SLED_APP_CTX', 'AUTHENTICATED') = 'Y'
                  AND SYS_CONTEXT('SLED_APP_CTX', 'ACCESS_SCOPE') = 'GLOBAL'
                 THEN (SELECT COUNT(*) FROM user_mining_models WHERE algorithm != 'ONNX')
                 ELSE 0
               END AS cnt
        FROM dual
      `),
      db.execute(`SELECT /*+ NO_PARALLEL */
        ROUND(REGR_SLOPE(day_rev, rn), 2) AS slope,
        ROUND(REGR_R2(day_rev, rn), 4) AS r2
        FROM (
          SELECT SUM(order_total) AS day_rev,
                 ROW_NUMBER() OVER (ORDER BY TRUNC(CAST(created_at AS DATE))) AS rn
          FROM orders WHERE CAST(created_at AS DATE) >= SYSDATE - 30
          GROUP BY TRUNC(CAST(created_at AS DATE))
        )`),
    ]);

    res.json({
      products_with_surge: surgeCount.rows[0]?.CNT || 0,
      total_customers: customers.rows[0]?.CNT || 0,
      rfm_segments: segmentCount.rows[0]?.CNT || 0,
      revenue_slope: regr.rows[0]?.SLOPE || 0,
      revenue_r2: regr.rows[0]?.R2 || 0,
      models_active: modelCount.rows[0]?.CNT || 0,
    });
  } catch (err) {
    return handleMlRouteError(res, 'ML summary', err, fallbackSummary);
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// GET /api/ml/vector-clusters
//
// Dynamically rebuilds PRODUCT_CLUSTER_MODEL with the requested K value
// so the number of clusters returned always matches the user's selection.
// ─────────────────────────────────────────────────────────────────────────────
router.get('/vector-clusters', requireGlobalAccess, async (req, res) => {
  try {
    const k = Math.min(Math.max(parseInt(req.query.k) || 5, 2), 15);
    try {
      return res.json(await getPersistedProductClusters({ k }));
    } catch (persistErr) {
      console.warn('Persisted case signal clusters unavailable; falling back to live scoring:', persistErr.message);
    }

    // Rebuild the model with the requested K so CLUSTER_ID returns exactly K clusters
    await db.execute(`
      BEGIN
        -- Drop existing model (ignore if not found)
        BEGIN
          DBMS_DATA_MINING.DROP_MODEL('PRODUCT_CLUSTER_MODEL');
        EXCEPTION WHEN OTHERS THEN NULL;
        END;

        -- Recreate settings table with requested K
        BEGIN EXECUTE IMMEDIATE 'DROP TABLE km_settings PURGE'; EXCEPTION WHEN OTHERS THEN NULL; END;
        EXECUTE IMMEDIATE 'CREATE TABLE km_settings (setting_name VARCHAR2(30), setting_value VARCHAR2(4000))';
        EXECUTE IMMEDIATE 'INSERT INTO km_settings VALUES (''ALGO_NAME'', ''ALGO_KMEANS'')';
        EXECUTE IMMEDIATE 'INSERT INTO km_settings VALUES (''CLUS_NUM_CLUSTERS'', ''' || :k_val || ''')';
        COMMIT;

        DBMS_DATA_MINING.CREATE_MODEL(
          model_name      => 'PRODUCT_CLUSTER_MODEL',
          mining_function => DBMS_DATA_MINING.CLUSTERING,
          data_table_name => 'OML_PRODUCT_CLUSTER_V',
          case_id_column_name => 'PRODUCT_ID',
          settings_table_name => 'km_settings'
        );
      END;
    `, { k_val: String(k) });

    // Now score with the freshly-built model
    const result = await db.execute(`
      WITH clustered AS (
        SELECT
          pcv.PRODUCT_ID,
          CLUSTER_ID(PRODUCT_CLUSTER_MODEL USING *) AS cluster_id,
          ROUND(CLUSTER_PROBABILITY(PRODUCT_CLUSTER_MODEL USING *), 4) AS cluster_prob,
          pcv.UNIT_PRICE,
          pcv.UNITS_SOLD,
          pcv.REVENUE AS product_revenue,
          pcv.TOTAL_ENGAGEMENT,
          pcv.AVG_SENTIMENT,
          pcv.AVG_VIRALITY
        FROM OML_PRODUCT_CLUSTER_V pcv
      )
      SELECT
        c.PRODUCT_ID,
        c.cluster_id,
        c.cluster_prob AS similarity,
        p.product_name,
        p.category,
        p.unit_price,
        b.brand_name,
        c.UNITS_SOLD,
        c.TOTAL_ENGAGEMENT,
        -- Find centroid (highest probability member in each cluster)
        FIRST_VALUE(p.product_name) OVER (
          PARTITION BY c.cluster_id ORDER BY c.cluster_prob DESC
        ) AS seed_name,
        FIRST_VALUE(c.PRODUCT_ID) OVER (
          PARTITION BY c.cluster_id ORDER BY c.cluster_prob DESC
        ) AS seed_id
      FROM clustered c
      JOIN products p ON c.PRODUCT_ID = p.PRODUCT_ID
      JOIN brands b   ON p.brand_id   = b.brand_id
      ORDER BY c.cluster_id, c.cluster_prob DESC
    `);

    // Group into clusters
    const clusterMap = {};
    result.rows.forEach(r => {
      const cid = r.CLUSTER_ID;
      if (!clusterMap[cid]) {
        clusterMap[cid] = {
          cluster_id: cid,
          centroid_product: r.SEED_NAME,
          centroid_product_id: r.SEED_ID,
          products: [],
          categories: {},
          total_similarity: 0,
        };
      }
      const cl = clusterMap[cid];
      cl.products.push({
        product_id: r.PRODUCT_ID,
        product_name: r.PRODUCT_NAME,
        category: r.CATEGORY,
        brand_name: r.BRAND_NAME,
        unit_price: r.UNIT_PRICE,
        similarity: r.SIMILARITY,
        is_centroid: r.PRODUCT_ID === r.SEED_ID,
      });
      cl.categories[r.CATEGORY] = (cl.categories[r.CATEGORY] || 0) + 1;
      cl.total_similarity += Number(r.SIMILARITY) || 0;
    });

    const clusters = Object.values(clusterMap).map(cl => ({
      cluster_id: cl.cluster_id,
      centroid_product: cl.centroid_product,
      size: cl.products.length,
      avg_similarity: Math.round((cl.total_similarity / cl.products.length) * 10000) / 10000,
      top_category: Object.entries(cl.categories).sort((a, b) => b[1] - a[1])[0]?.[0] || '',
      category_breakdown: cl.categories,
      products: cl.products,
    }));

    res.json({
      k,
      total_products: result.rows.length,
      clusters,
      meta: {
        model: `PRODUCT_CLUSTER_MODEL (K-Means, ${k} clusters)`,
        algorithm: 'ALGO_KMEANS',
        scoring: 'CLUSTER_ID() / CLUSTER_PROBABILITY()',
        features: ['unit_price', 'weight_kg', 'units_sold', 'revenue', 'order_count',
                   'total_engagement', 'avg_sentiment', 'avg_virality'],
        engine: 'Oracle DBMS_DATA_MINING - in-database K-Means Clustering',
      },
    });
  } catch (err) {
    const k = Math.min(Math.max(parseInt(req.query.k) || 5, 2), 15);
    return handleMlRouteError(res, 'ML vector-clusters', err, () =>
      fallbackVectorClusters({ k })
    );
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// GET /api/ml/inventory-intelligence
//
// OML-powered inventory alerts: joins DEMAND_SURGE_MODEL predictions
// (stored in demand_forecasts) with live inventory levels to identify
// products at risk of stockout due to social-driven demand surges.
// ─────────────────────────────────────────────────────────────────────────────
router.get('/inventory-intelligence', async (req, res) => {
  try {
    try {
      return res.json(await getPersistedCapacityIntelligence());
    } catch (persistErr) {
      console.warn('Persisted capacity intelligence unavailable; falling back to live scoring:', persistErr.message);
    }

    // Get OML-scored inventory alerts
    const alertsResult = await db.execute(`
      SELECT
        p.product_id, p.product_name, p.category, p.unit_price,
        b.brand_name,
        fc.center_id, fc.service_region_code, fc.center_name, fc.city, fc.state_province,
        i.quantity_on_hand, i.reorder_point, i.quantity_reserved,
        i.quantity_on_hand - i.reorder_point AS deficit,
        NVL(df.predicted_demand, 0) AS predicted_demand,
        NVL(df.social_factor, 1.0) AS social_factor,
        NVL(df.confidence_low, 0) AS confidence_low,
        NVL(df.confidence_high, 0) AS confidence_high,
        df.model_version,
        -- OML: real-time surge prediction
        PREDICTION(DEMAND_SURGE_MODEL USING
          p.CATEGORY AS category, p.UNIT_PRICE AS unit_price,
          NVL(eng.TOTAL_POSTS, 0) AS total_posts,
          NVL(eng.AVG_SENTIMENT, 0.5) AS avg_sentiment,
          NVL(eng.TOTAL_LIKES, 0) AS total_likes,
          NVL(eng.TOTAL_SHARES, 0) AS total_shares,
          NVL(eng.TOTAL_VIEWS, 0) AS total_views,
          NVL(eng.AVG_VIRALITY, 0) AS avg_virality,
          NVL(eng.VIRAL_POSTS, 0) AS viral_posts,
          NVL(eng.RISING_POSTS, 0) AS rising_posts,
          NVL(sales.UNITS_SOLD, 0) AS units_sold,
          NVL(sales.REVENUE, 0) AS revenue
        ) AS oml_surge_prediction,
        ROUND(PREDICTION_PROBABILITY(DEMAND_SURGE_MODEL, 'SURGE' USING
          p.CATEGORY AS category, p.UNIT_PRICE AS unit_price,
          NVL(eng.TOTAL_POSTS, 0) AS total_posts,
          NVL(eng.AVG_SENTIMENT, 0.5) AS avg_sentiment,
          NVL(eng.TOTAL_LIKES, 0) AS total_likes,
          NVL(eng.TOTAL_SHARES, 0) AS total_shares,
          NVL(eng.TOTAL_VIEWS, 0) AS total_views,
          NVL(eng.AVG_VIRALITY, 0) AS avg_virality,
          NVL(eng.VIRAL_POSTS, 0) AS viral_posts,
          NVL(eng.RISING_POSTS, 0) AS rising_posts,
          NVL(sales.UNITS_SOLD, 0) AS units_sold,
          NVL(sales.REVENUE, 0) AS revenue
        ) * 100, 1) AS oml_surge_probability,
        -- Stock risk assessment
        CASE
          WHEN i.quantity_on_hand = 0 THEN 'OUT_OF_STOCK'
          WHEN i.quantity_on_hand < i.reorder_point * 0.5 THEN 'CRITICAL'
          WHEN i.quantity_on_hand < i.reorder_point THEN 'LOW'
          WHEN i.quantity_on_hand < NVL(df.predicted_demand, i.reorder_point) THEN 'AT_RISK'
          ELSE 'ADEQUATE'
        END AS stock_status,
        -- Days of supply remaining
        CASE WHEN NVL(df.predicted_demand, 0) > 0
          THEN ROUND(i.quantity_on_hand / (df.predicted_demand / 7), 1)
          ELSE NULL
        END AS days_of_supply,
        -- Revenue at risk
        CASE WHEN i.quantity_on_hand < NVL(df.predicted_demand, 0)
          THEN ROUND((NVL(df.predicted_demand, 0) - i.quantity_on_hand) * p.unit_price, 2)
          ELSE 0
        END AS revenue_at_risk
      FROM inventory i
      JOIN products p ON i.product_id = p.product_id
      JOIN brands b ON p.brand_id = b.brand_id
      JOIN fulfillment_centers fc ON i.center_id = fc.center_id
      LEFT JOIN demand_forecasts df ON p.product_id = df.product_id
          AND df.forecast_date = TRUNC(SYSDATE)
      LEFT JOIN (
          SELECT ppm.PRODUCT_ID,
                 COUNT(*) AS TOTAL_POSTS, AVG(sp.SENTIMENT_SCORE) AS AVG_SENTIMENT,
                 SUM(sp.LIKES_COUNT) AS TOTAL_LIKES, SUM(sp.SHARES_COUNT) AS TOTAL_SHARES,
                 SUM(sp.VIEWS_COUNT) AS TOTAL_VIEWS, AVG(sp.VIRALITY_SCORE) AS AVG_VIRALITY,
                 SUM(CASE WHEN sp.MOMENTUM_FLAG='viral' THEN 1 ELSE 0 END) AS VIRAL_POSTS,
                 SUM(CASE WHEN sp.MOMENTUM_FLAG='rising' THEN 1 ELSE 0 END) AS RISING_POSTS
          FROM POST_PRODUCT_MENTIONS ppm
          JOIN SOCIAL_POSTS sp ON ppm.POST_ID = sp.POST_ID
          GROUP BY ppm.PRODUCT_ID
      ) eng ON p.PRODUCT_ID = eng.PRODUCT_ID
      LEFT JOIN (
          SELECT PRODUCT_ID, SUM(QUANTITY) AS UNITS_SOLD, SUM(LINE_TOTAL) AS REVENUE
          FROM ORDER_ITEMS GROUP BY PRODUCT_ID
      ) sales ON p.PRODUCT_ID = sales.PRODUCT_ID
      WHERE fc.is_active = 1
      ORDER BY oml_surge_probability DESC, i.quantity_on_hand ASC
      FETCH FIRST 100 ROWS ONLY
    `);

    // Summary stats
    const alerts = alertsResult.rows;
    const critical = alerts.filter(a => a.STOCK_STATUS === 'CRITICAL' || a.STOCK_STATUS === 'OUT_OF_STOCK').length;
    const atRisk = alerts.filter(a => a.STOCK_STATUS === 'AT_RISK').length;
    const surgeProducts = alerts.filter(a => a.OML_SURGE_PREDICTION === 'SURGE').length;
    const totalRevenueAtRisk = alerts.reduce((sum, a) => sum + (Number(a.REVENUE_AT_RISK) || 0), 0);

    // Group by stock status for chart
    const statusDist = {};
    alerts.forEach(a => {
      statusDist[a.STOCK_STATUS] = (statusDist[a.STOCK_STATUS] || 0) + 1;
    });

    // Group by center
    const centerMap = {};
    alerts.forEach(a => {
      if (!centerMap[a.CENTER_NAME]) {
        centerMap[a.CENTER_NAME] = { center: a.CENTER_NAME, city: a.CITY, alerts: 0, critical: 0, surges: 0 };
      }
      centerMap[a.CENTER_NAME].alerts++;
      if (a.STOCK_STATUS === 'CRITICAL' || a.STOCK_STATUS === 'OUT_OF_STOCK') centerMap[a.CENTER_NAME].critical++;
      if (a.OML_SURGE_PREDICTION === 'SURGE') centerMap[a.CENTER_NAME].surges++;
    });

    res.json({
      alerts,
      summary: {
        total_alerts: alerts.length,
        critical_count: critical,
        at_risk_count: atRisk,
        surge_products: surgeProducts,
        total_revenue_at_risk: Math.round(totalRevenueAtRisk * 100) / 100,
      },
      statusDistribution: Object.entries(statusDist).map(([status, count]) => ({ status, count })),
      centerSummary: Object.values(centerMap).sort((a, b) => b.critical - a.critical),
      meta: {
        model: 'DEMAND_SURGE_MODEL (Random Forest) + demand_forecasts',
        scoring: 'PREDICTION() + PREDICTION_PROBABILITY() real-time',
        engine: 'Oracle DBMS_DATA_MINING + inventory JOIN',
      },
    });
  } catch (err) {
    return handleMlRouteError(res, 'ML inventory-intelligence', err, fallbackInventoryIntelligence);
  }
});

module.exports = router;
