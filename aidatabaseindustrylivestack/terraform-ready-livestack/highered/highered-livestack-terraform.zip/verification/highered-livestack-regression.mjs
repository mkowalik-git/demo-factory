#!/usr/bin/env node
/*
 * Focused regression runner for a deployed HigherEd LiveStack. It validates
 * the routes this application actually exposes and never seeds/imports data.
 * The optional agent test writes one proposed advisory audit record.
 *
 * Usage:
 *   node highered-livestack-regression.mjs --base-url http://host:8505
 *   node highered-livestack-regression.mjs --base-url http://host:8505 --skip-chat
 *   node highered-livestack-regression.mjs --base-url http://host:8505 --include-agent-chat
 */

import assert from 'node:assert/strict';
import process from 'node:process';

function argument(name, fallback = undefined) {
  const index = process.argv.indexOf(name);
  return index === -1 ? fallback : process.argv[index + 1] || fallback;
}

const rawBaseUrl = argument('--base-url');
if (!rawBaseUrl) {
  console.error('Usage: node highered-livestack-regression.mjs --base-url http://host:8505 [--skip-chat] [--include-agent-chat]');
  process.exit(2);
}

const baseUrl = rawBaseUrl.replace(/\/+$/, '');
const timeoutMs = Number(argument('--timeout-ms', '120000'));
const agentTimeoutMs = Number(argument('--agent-timeout-ms', '900000'));
const runChat = !process.argv.includes('--skip-chat');
const runAgentChat = process.argv.includes('--include-agent-chat');
const results = [];
let sessionCookie = '';
let demoActor = '';

function value(object, ...keys) {
  return keys.map((key) => object?.[key]).find((candidate) => candidate !== undefined && candidate !== null);
}

function nonEmptyArray(payload, label) {
  assert.ok(Array.isArray(payload), `${label} must be an array`);
  assert.ok(payload.length > 0, `${label} must not be empty`);
  return payload;
}

function sessionCookieFrom(response) {
  const values = typeof response.headers.getSetCookie === 'function'
    ? response.headers.getSetCookie()
    : [response.headers.get('set-cookie')];
  const first = values.find(Boolean);
  return first ? first.split(';', 1)[0] : '';
}

async function http(label, path, { method = 'GET', body, timeout = timeoutMs, auth = true, expectedStatus = 200, headers = {} } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const response = await fetch(`${baseUrl}${path}`, {
      method,
      headers: {
        accept: 'application/json',
        ...(body ? { 'content-type': 'application/json' } : {}),
        ...(auth && sessionCookie ? { cookie: sessionCookie, 'x-demo-user': demoActor } : {}),
        ...headers,
      },
      body: body ? JSON.stringify(body) : undefined,
      signal: controller.signal,
    });
    const text = await response.text();
    let payload;
    try {
      payload = text ? JSON.parse(text) : null;
    } catch {
      throw new Error(`${label} returned non-JSON content: ${text.slice(0, 240)}`);
    }
    assert.equal(response.status, expectedStatus, `${label} returned HTTP ${response.status}: ${JSON.stringify(payload).slice(0, 500)}`);
    return { payload, response };
  } finally {
    clearTimeout(timer);
  }
}

async function test(label, callback) {
  const started = Date.now();
  try {
    await callback();
    results.push({ label, status: 'PASS', elapsedMs: Date.now() - started });
    console.log(`PASS  ${label}`);
  } catch (error) {
    results.push({ label, status: 'FAIL', elapsedMs: Date.now() - started, error: error.message });
    console.error(`FAIL  ${label}: ${error.message}`);
  }
}

async function createDemoSession() {
  const { payload: users } = await http('demo users', '/api/users', { auth: false });
  const user = nonEmptyArray(users, 'demo users')[0];
  demoActor = String(value(user, 'USERNAME', 'username') || '');
  assert.ok(demoActor, 'demo users did not return a username');
  const { payload, response } = await http('demo session', '/api/demo-session', {
    method: 'POST',
    body: { actor: demoActor },
    auth: false,
    expectedStatus: 201,
    headers: {
      origin: baseUrl,
      'x-highered-demo-control': 'highered-demo-session',
    },
  });
  assert.equal(payload.actor, demoActor, 'demo session actor did not match the requested user');
  sessionCookie = sessionCookieFrom(response);
  assert.ok(sessionCookie.startsWith('highered_demo_session='), 'demo session did not return a signed session cookie');
}

async function main() {
  await test('connection: API health queries ADB and native readiness', async () => {
    const { payload } = await http('API health', '/api/health', { auth: false });
    assert.equal(payload.status, 'healthy');
    assert.equal(value(payload.database, 'STATUS', 'status'), 'connected');
    assert.equal(payload.native_ai?.ready, true, 'API health did not report native Select AI readiness');
  });

  await test('signed demo session for governed routes', createDemoSession);

  await test('seeded HigherEd data and derived artifacts', async () => {
    const { payload } = await http('demo status', '/api/demo/status');
    for (const key of ['products', 'orders', 'social_posts', 'fulfillment_zones', 'product_embeddings', 'post_embeddings', 'semantic_matches']) {
      assert.ok(Number(payload[key]) > 0, `demo status ${key} is empty`);
    }
  });

  const simpleGetTests = [
    ['dashboard summary', '/api/dashboard/summary', (body) => assert.ok(Number(value(body, 'ORDERS_TOTAL', 'orders_total')) > 0)],
    ['risk signal feed', '/api/social/posts?limit=2', (body) => nonEmptyArray(body.posts, 'risk signal posts')],
    ['campus service sites', '/api/fulfillment/centers', (body) => nonEmptyArray(body, 'campus service sites')],
    ['operational event graph', '/api/graph/influencers?limit=1', (body) => nonEmptyArray(body, 'operational event graph')],
    ['OML summary', '/api/ml/summary', (body) => assert.equal(typeof body, 'object')],
    ['Ask HigherEd profiles', '/api/selectai/profiles', (body) => nonEmptyArray(body.profiles, 'Select AI profiles')],
    ['Ask HigherEd schema metadata', '/api/selectai/schema-objects', (body) => nonEmptyArray(body.objects, 'Select AI schema objects')],
    ['Ask HigherEd metadata health', '/api/selectai/health', (body) => assert.equal(body.status, 'healthy')],
    ['agent profiles', '/api/agents/profiles', (body) => assert.equal(typeof body, 'object')],
    ['agent teams', '/api/agents/teams', (body) => {
      const teams = nonEmptyArray(body, 'agent teams').map((row) => row.TEAM_NAME);
      assert.deepEqual(teams, ['STUDENT_SIGNAL_TEAM', 'CAMPUS_SERVICE_TEAM', 'STUDENT_SUCCESS_TEAM']);
    }],
    ['agent audit view', '/api/agents/actions?limit=3', (body) => assert.ok(Array.isArray(body), 'agent audit view must be an array')],
    ['import dataset metadata', '/api/import/dataset', (body) => assert.equal(typeof body, 'object')],
  ];

  for (const [label, path, assertion] of simpleGetTests) {
    await test(label, async () => {
      const { payload } = await http(label, path);
      assertion(payload);
    });
  }

  const question = 'Which campus service sites are at risk of capacity pressure?';
  await test('governed natural-language SQL', async () => {
    const { payload } = await http('governed natural-language SQL', '/api/selectai/runsql', {
      method: 'POST', body: { question }, timeout: 190000,
    });
    assert.ok(Array.isArray(payload.columns) && payload.columns.length > 0, 'governed SQL returned no columns');
    assert.ok(Array.isArray(payload.rows), 'governed SQL returned no rows array');
    assert.equal(typeof payload.sql, 'string', 'governed SQL did not return generated SQL');
    assert.equal(payload.readOnly, true, 'governed SQL did not retain the read-only boundary');
  });

  if (runChat) {
    await test('native Ask HigherEd explanation', async () => {
      const { payload } = await http('native Ask HigherEd explanation', '/api/selectai/chat-mode', {
        method: 'POST',
        body: { question, showSql: false, history: [] },
        timeout: 190000,
      });
      assert.equal(typeof payload.answer, 'string', 'native chat has no answer');
      assert.equal(payload.provider, 'OCI Generative AI', 'native chat did not identify OCI Generative AI');
      assert.equal(payload.evidence?.package, 'DBMS_CLOUD_AI', 'native chat did not identify DBMS_CLOUD_AI evidence');
      assert.equal(payload.readOnly, true, 'native chat did not retain the read-only boundary');
      assert.equal(payload.sql, null, 'native chat exposed governed SQL while showSql was disabled');
      assert.equal(payload.evidence?.generatedSql, true, 'native chat did not generate governed SQL');
      assert.equal(payload.evidence?.executed, true, 'native chat did not execute governed SQL');
    });
  } else {
    results.push({ label: 'native Ask HigherEd explanation', status: 'SKIP', elapsedMs: 0 });
    console.log('SKIP  native Ask HigherEd explanation');
  }

  if (runAgentChat) {
    await test('native Agent Console advisory request', async () => {
      const { payload } = await http('native Agent Console advisory request', '/api/agents/chat', {
        method: 'POST',
        body: {
          question: 'Which student and community signals need follow-up?',
          team: 'STUDENT_SIGNAL_TEAM',
        },
        timeout: agentTimeoutMs,
      });
      assert.equal(typeof payload.response, 'string', 'agent chat has no response');
      assert.equal(payload.team, 'STUDENT_SIGNAL_TEAM', 'agent chat did not preserve specialist routing');
      assert.equal(payload.provider, 'OCI Generative AI', 'agent chat did not identify OCI Generative AI');
      assert.equal(payload.package, 'DBMS_CLOUD_AI_AGENT', 'agent chat did not identify DBMS_CLOUD_AI_AGENT');
      assert.equal(payload.action, 'RUN_TEAM', 'agent chat did not identify the native team action');
      assert.equal(payload.advisory, true, 'agent chat did not retain its advisory boundary');
      assert.equal(payload.readOnly, true, 'agent chat did not retain its read-only boundary');
      assert.deepEqual(payload.agentToolsUsed, [], 'tool-free native agent tasks reported an attached tool');
      assert.equal(payload.grounding?.vpdFiltered, true, 'agent chat did not report VPD-filtered grounding');
    });
  } else {
    results.push({ label: 'native Agent Console advisory request', status: 'SKIP', elapsedMs: 0 });
    console.log('SKIP  native Agent Console advisory request (use --include-agent-chat to run; it writes one proposed audit record)');
  }

  const passed = results.filter((result) => result.status === 'PASS').length;
  const failed = results.filter((result) => result.status === 'FAIL');
  const skipped = results.filter((result) => result.status === 'SKIP').length;
  console.log(`\nHigherEd regression summary: ${passed} passed, ${failed.length} failed, ${skipped} skipped.`);
  if (failed.length) {
    console.log(JSON.stringify({ baseUrl, failed }, null, 2));
    process.exitCode = 1;
  } else {
    console.log('HIGHERED_API_REGRESSION_OK');
  }
}

main().catch((error) => {
  console.error(`Fatal regression-runner error: ${error.stack || error.message}`);
  process.exitCode = 2;
});
