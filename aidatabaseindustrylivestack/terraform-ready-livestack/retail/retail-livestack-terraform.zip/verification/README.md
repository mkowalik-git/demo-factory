# Post-deployment regression check

`retail-livestack-regression.mjs` is an operator-run regression check for a
deployed Retail LiveStack. It does not modify Retail business data.
Terraform and cloud-init never execute it automatically.

Run it from a workstation with Node.js 20 or later after the stack output
`first_boot_status_command` prints `RESOURCE_MANAGER_DEPLOYMENT_OK`:

```bash
node verification/retail-livestack-regression.mjs \
  --base-url http://PUBLIC_IP:8505
```

The standard run checks the browser-loadable frontend, database-backed health,
seeded data, graph, capacity, OML, and native Select AI metadata/readiness. It
does not invoke data import/restore routes, rebuild OML models, create Select AI
conversations, or create Agent Console audit actions.

To include the Agent Console two-turn follow-up check, add
`--include-agent-chat`. That optional check adds two normal chat audit records
to the demo database.

`Retail_API_REGRESSION_OK` is the expected final marker. A nonzero exit code
or any `FAIL` line identifies the failing route.

## Published AI-card quality suite

Run every published Ask Data and Agent Console card after the standard suite:

```bash
node verification/retail-ai-card-regression.mjs \
  --base-url http://PUBLIC_IP:8505
```

This suite executes all nine Ask Data cards in Run SQL and Narrate modes and
all eight Agent Console cards with their explicit native team. In addition to
HTTP status, it validates the reviewed SQL guards, read-only/advisory boundary,
first-row ranking, cited evidence, non-null creator and urgency contracts, and
absence of SQL/query blocks in user-facing prose.

The suite invokes OCI Generative AI, creates short-lived Select AI
conversations, and adds eight normal proposed rows to `AGENT_ACTIONS`. It does
not execute operational recommendations or change Retail business data.
`RETAIL_AI_CARD_REGRESSION_OK` is the required final marker.
